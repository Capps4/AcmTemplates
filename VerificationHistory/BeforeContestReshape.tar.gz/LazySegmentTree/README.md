# LazySegmentTree GNU++17

LazySegT<Info,Tag>：单点赋值、区间合并、区间标记、findFirst/findLast。

泛型递归 lambda 建树；递归引用传谓词，支持 move-only 谓词。容量 2*ceilPow2(n)，空树安全构造。区间 [l,r)，空修改是 no-op，空搜索返回 -1；rangeQuery 要求非空。Info::operator+ 必须结合，Tag::apply 表示先旧标记后新标记。搜索谓词若对整段为 false，必须保证整段没有满足条件的叶子。

类型名大驼峰，函数和变量小驼峰；下标 0index，所有区间 [l,r)。函数名保留兼容。

## 验证

朴素数组随机区间/单点操作、sum/max 合并、左右搜索；不可复制谓词；非交换 affine 标记组合；空树。

运行 `python3 ../Run.py LazySegmentTree`（工作目录任意，需将脚本路径指向 cpp17/Run.py）。测试覆盖 GCC -O2 和 Clang ASan/UBSan。

## 性能

建树、区间更新查询、捕获 vector 的搜索分开比较。示例 Tag.add 改为 long long，乘法/求和仍需由题目约束保证不溢出。

输入固定种子、预热一次、每项七轮中位数，旧/新结果校验和必须一致。实际数据见 Benchmark.csv 和 Results.json。仅代表此机器/编译器/工作负载，不推断所有输入下的速度。

## 交付与自我 Review

Final.hpp 为唯一源码；Final.code-snippets 从标记后的正文自动生成。已核对职责保持、API 前置条件、边界、复杂度及新增数据结构必要性。原 snippets 未覆盖。

当前计时方法及数据见 [Performance.md](Performance.md)。本文已有数字属于此前计时记录，原报告保存在 `../VerificationHistory/BeforeTimingFence/`；以 Performance.md 为当前性能依据。
