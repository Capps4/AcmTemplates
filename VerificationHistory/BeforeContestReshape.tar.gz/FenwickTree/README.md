# FenwickTree GNU++17

Fenwick<T,Merge> 用 O(n) 建树。可传入带状态合并对象和显式单位元，支持 CTAD、move-only 且 const-callable 的合并对象；合并须交换、结合且 identity 为双侧单位元。Max<T> 允许传比较器，负值求最大值需明确 INT_MIN 等单位元。

modify(i,value) 将 value 合并到位置 i，不是赋值。prefixQuery(r) 返回 [0,r)，posQuery(i) 保留旧的闭区间前缀 [0,i]（i==-1 为空）。rangeQuery(l,r) 仅对 std::plus 的加法群有效。maxPrefix(k) 返回前缀聚合 <=k 的最大右端 r，select(k) 保留旧接口返回 r-1。选择要求前缀聚合关于 <= 单调，例如非负计数和；没有符合条件的非空前缀时返回 0/-1。空树可构造并查询空前缀。顶点下标 0index，类型大驼峰，函数/变量小驼峰。

内部更新用 unsigned 防止容量接近 INT_MAX 时有符号下标步进溢出；最高二进制步长在构造时缓存，选择中每个候选只合并一次。时间 O(log n)，空间 O(n)，T 和 Merge 的具体操作成本另计。n 和元素数必须在 [0,INT_MAX]。

Test.cpp 比较朴素数组与逐点建树，随机更新、前缀、区间和选择；显式最大值单位元、move-only XOR、vector<bool>。基准包含线性建树、更新/查询及前缀选择；相同输入七轮中位数，GCC -O2 + Clang ASan/UBSan 的记录见 Results.json。

自我 Review：不改变合并型 Fenwick 的职责；保留 posQuery/select 语义，用明确命名的新接口提供半开前缀。没有把任意 merge 宣称为支持减法或非单调选择。单位元是对象成员，不引入运行时函数擦除。源码和 snippet 一致性由 Export.py 校验。

当前计时方法及数据见 [Performance.md](Performance.md)。本文已有数字属于此前计时记录，原报告保存在 `../VerificationHistory/BeforeTimingFence/`；以 Performance.md 为当前性能依据。
