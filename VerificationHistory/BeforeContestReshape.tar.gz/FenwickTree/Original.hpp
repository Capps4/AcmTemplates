#pragma once
#include <bits/stdc++.h>
using i64 = long long;
template <class T, class Cmp = std::greater<T>>
struct Max {
    const Cmp cmp = Cmp();
    constexpr T operator()(const T &a, const T &b) const {
        return std::min(a, b, cmp);
    }
};

template <class T, class Merge = std::plus<T>>
class Fenwick {
    const int n;
    std::vector<T> t;
    const Merge merge;
public:
    Fenwick(int n) : n{n}, t(n + 1), merge(Merge()) {}

    // O(n) build Fenwick
    Fenwick(const std::vector<T> &a) : Fenwick(a.size()) {
        for (int i = 1; i <= n; i++) {
            t[i] = merge(t[i], a[i - 1]);
            int j = i + (i & -i);
            if (j <= n) {
                t[j] = merge(t[j], t[i]);
            }
        }
    }

    void modify(int i, const T &x) {
        for (i += 1; i <= n; i += i & -i) {
            t[i] = merge(t[i], x);
        }
    }

    T posQuery(int i) const {
        T res = T{};
        for (i += 1; i > 0; i -= i & -i) {
            res = merge(res, t[i]);
        }
        return res;
    }

    // [l, r)
    // T rangeQuery(int l, int r) {
    //     return posQuery(r - 1) - posQuery(l - 1);
    // }

    // 合并起来 <= k 的最长前缀
    int select(const T &k) const {
        int x = 0;
        T cur{};
        for (int i = 1 << std::__lg(n); i > 0; i /= 2) {
            if (x + i <= n and merge(cur, t[x + i]) <= k) {
                x += i;
                cur = merge(cur, t[x]);
            }
        }
        return x - 1;
    }
};

