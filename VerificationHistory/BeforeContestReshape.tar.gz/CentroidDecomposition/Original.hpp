#pragma once
#include <bits/stdc++.h>
using i64 = long long;
class CentroidDecomposition {
    const std::vector<std::vector<int>> &adj;
    std::vector<bool> vis;
    std::vector<int> size;

    void dfsSize(int x, int fa) {
        size[x] = 1;
        for (int y : adj[x]) {
            if (y != fa and !vis[y]) {
                dfsSize(y, x);
                size[x] += size[y];
            }
        }
    }

    int getRoot(int x, int fa, int m) {
        for (int y : adj[x]) {
            if (y != fa and !vis[y] and 2 * size[y] > m) {
                return getRoot(y, x, m);
            }
        }
        return x;
    }

    void build(int x) {
        vis[x] = true;
        dfsOrder.push_back(x);

        for (int y : adj[x]) {
            if (!vis[y]) {
                dfsSize(y, -1);
                y = getRoot(y, -1, size[y]);
                // cdt[x].push_back(y);
                build(y);
            }
        }
    }

public:
    // std::vector<std::vector<int>> cdt;
    std::vector<int> dfsOrder;
    CentroidDecomposition(const std::vector<std::vector<int>> &g)
        : adj(g),
          vis(g.size()),
          size(g.size()),
          //   cdt(g.size()),
          dfsOrder() {

        dfsSize(0, -1);
        dfsOrder.reserve(g.size());
        int root = getRoot(0, -1, size[0]);
        build(root);
    }
};

