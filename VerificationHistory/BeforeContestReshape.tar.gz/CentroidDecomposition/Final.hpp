#pragma once
#include <cassert>
#include <cstddef>
#include <limits>
#include <utility>
#include <vector>

// SNIPPET BEGIN
class CentroidDecomposition {
public:
    std::vector<int> dfsOrder, centroidParent;
    explicit CentroidDecomposition(const std::vector<std::vector<int>>& adj)
        : centroidParent(adj.size(), -1) {
        assert(adj.size() <= std::size_t(std::numeric_limits<int>::max()));
        int n = int(adj.size());
        std::vector<unsigned char> removed(n);
        std::vector<int> parent(n), size(n), nodes;
        std::vector<std::pair<int, int>> pending;
        nodes.reserve(n);
        pending.reserve(n);
        dfsOrder.reserve(n);
        for (int root = 0; root < n; ++root) {
            if (removed[root]) continue;
            pending.emplace_back(root, -1);
            while (!pending.empty()) {
                auto [start, ancestor] = pending.back();
                pending.pop_back();
                nodes.clear();
                nodes.push_back(start);
                parent[start] = -1;
                size[start] = 1;
                for (std::size_t head = 0; head < nodes.size(); ++head) {
                    int vertex = nodes[head];
                    for (int next : adj[vertex]) {
                        assert(0 <= next && next < n);
                        if (removed[next] || next == parent[vertex]) continue;
                        assert(nodes.size() < adj.size()); // Input must be a forest.
                        parent[next] = vertex;
                        size[next] = 1;
                        nodes.push_back(next);
                    }
                }
                for (std::size_t i = nodes.size(); i-- > 0;) {
                    int vertex = nodes[i];
                    if (parent[vertex] != -1) size[parent[vertex]] += size[vertex];
                }
                int centroid = start;
                for (;;) {
                    int heavy = -1;
                    for (int next : adj[centroid]) if (!removed[next] && parent[next] == centroid &&
                                                     size[next] > int(nodes.size() / 2)) {
                        heavy = next;
                        break;
                    }
                    if (heavy == -1) break;
                    centroid = heavy;
                }
                removed[centroid] = true;
                centroidParent[centroid] = ancestor;
                dfsOrder.push_back(centroid);
                for (auto it = adj[centroid].rbegin(); it != adj[centroid].rend(); ++it)
                    if (!removed[*it]) pending.emplace_back(*it, centroid);
            }
        }
    }
};
