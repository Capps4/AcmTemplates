"""Generate VS Code snippets from the exact final header body."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MARKER = '// SNIPPET BEGIN\n'
CURSOR = '// SNIPPET CURSOR'

def header_body(module):
    return (ROOT / module / 'Final.hpp').read_text().split(MARKER, 1)[1].rstrip('\n')

def expand(body, internal_cursor=False, restore_cursor=False):
    lines = []
    for line in body:
        if line.strip() == '$0':
            if internal_cursor:
                indent = line[:len(line) - len(line.lstrip())]
                lines.append(indent + (CURSOR if restore_cursor else ''))
        else:
            lines.append(line.replace('\\$', '$').replace('\\\\', '\\'))
    return '\n'.join(lines)

def export(module):
    directory = ROOT / module
    source = header_body(module)
    internal_cursor = CURSOR in source
    assert source.count(CURSOR) <= 1
    body = [line.replace(CURSOR, '$0') if line.strip() == CURSOR
            else line.replace('\\', '\\\\').replace('$', '\\$') for line in source.splitlines()]
    if not internal_cursor:
        body.append('$0')
    data = json.loads((directory / 'Original.code-snippets').read_text())
    entry = next(iter(data.values()))
    entry['body'] = body
    entry['description'] = f'{module}: GNU++17 final'
    target = directory / 'Final.code-snippets'
    target.write_text(json.dumps(data, ensure_ascii=False, indent=4) + '\n')
    expanded = expand(body, internal_cursor, restore_cursor=True)
    assert expanded == source, module

if __name__ == '__main__':
    for directory in sorted(ROOT.iterdir()):
        if directory.is_dir() and (directory / 'Final.hpp').exists():
            export(directory.name)
