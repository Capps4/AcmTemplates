#pragma once
#include <cassert>
#include <type_traits>

// SNIPPET BEGIN
// P>0: fixed modulus; P==0: shared runtime modulus for this T.
template<class T, T P>
class ModuloInteger {
    static_assert(std::is_same_v<T, int> || std::is_same_v<T, long long>);
    static_assert(P >= 0);
    using U = std::make_unsigned_t<T>;
    using Wide = std::conditional_t<sizeof(T) <= 4, long long, __int128>;
    inline static T mod = sizeof(T) <= 4 ? T(998244353) : T(4179340454199820289LL);
    T x = 0;

    static constexpr ModuloInteger raw(T value) {
        ModuloInteger result;
        result.x = value;
        return result;
    }
public:
    using ValueType = T;
    constexpr ModuloInteger() = default;
    template<class I, std::enable_if_t<std::is_integral_v<I>, int> = 0>
    constexpr ModuloInteger(I value) {
        if constexpr (std::is_signed_v<I>) {
            using Input = std::conditional_t<(sizeof(I) <= 8), long long, __int128>;
            auto remainder = Input(value) % getMod();
            x = T(remainder < 0 ? remainder + getMod() : remainder);
        } else {
            using Input = std::conditional_t<(sizeof(I) <= 8), unsigned long long, unsigned __int128>;
            x = T(Input(value) % U(getMod()));
        }
    }
    static constexpr T getMod() {
        if constexpr (P > 0) return P;
        else return mod;
    }
    static void setMod(T value) {
        static_assert(P == 0, "setMod requires a runtime-modulus type");
        assert(value > 0);
        mod = value;
    }
    constexpr T val() const { return x; }
    explicit constexpr operator T() const { return x; }
    constexpr ModuloInteger operator-() const { return raw(x == 0 ? 0 : getMod() - x); }
    constexpr ModuloInteger& operator+=(ModuloInteger rhs) & {
        U sum = U(x) + U(rhs.x), modulus = U(getMod());
        x = T(sum >= modulus ? sum - modulus : sum);
        return *this;
    }
    constexpr ModuloInteger& operator-=(ModuloInteger rhs) & {
        x -= rhs.x;
        if (x < 0) x += getMod();
        return *this;
    }
    constexpr ModuloInteger& operator*=(ModuloInteger rhs) & {
        x = T(Wide(x) * rhs.x % getMod());
        return *this;
    }
    // Negative exponent and division require a prime modulus and nonzero base/divisor.
    constexpr ModuloInteger power(long long exponent) const {
        ModuloInteger base = *this, result = 1;
        auto magnitude = static_cast<unsigned long long>(exponent);
        if (exponent < 0) { base = inv(); magnitude = 0ULL - magnitude; }
        for (; magnitude; magnitude >>= 1) {
            if (magnitude & 1) result *= base;
            base *= base;
        }
        return result;
    }
    constexpr ModuloInteger inv() const {
        assert(x != 0);
        return power(getMod() - 2);
    }
    constexpr ModuloInteger& operator/=(ModuloInteger rhs) & { return *this *= rhs.inv(); }
    friend constexpr ModuloInteger operator+(ModuloInteger a, ModuloInteger b) { return a += b; }
    friend constexpr ModuloInteger operator-(ModuloInteger a, ModuloInteger b) { return a -= b; }
    friend constexpr ModuloInteger operator*(ModuloInteger a, ModuloInteger b) { return a *= b; }
    friend constexpr ModuloInteger operator/(ModuloInteger a, ModuloInteger b) { return a /= b; }
    friend constexpr bool operator==(ModuloInteger a, ModuloInteger b) { return a.x == b.x; }
    friend constexpr bool operator!=(ModuloInteger a, ModuloInteger b) { return a.x != b.x; }
    template<class Input>
    friend Input& operator>>(Input& in, ModuloInteger& value) {
        long long parsed;
        if (in >> parsed) value = ModuloInteger(parsed);
        return in;
    }
    template<class Output>
    friend Output& operator<<(Output& out, ModuloInteger value) {
        out << value.val();
        return out;
    }
};

inline constexpr int P = 998244353;
using Z = ModuloInteger<std::remove_cv_t<decltype(P)>, P>;
