#pragma once

// SNIPPET BEGIN
#if __has_include(<bits/stdc++.h>)
#include <bits/stdc++.h>
#else
#include <iostream>
#endif

using I64 = long long;
using i64 = I64;

void solve() {
    // SNIPPET CURSOR
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int cases = 0;
    if (!(std::cin >> cases) || cases < 0) return 0;
    for (int index = 0; index < cases; ++index) solve();

    return 0;
}
