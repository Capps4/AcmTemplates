# init_case

保留 solve/main 分离和原 iostream 设置。读入 cases 失败或为负数时直接返回，修复旧版未初始化 t 和负数 while(t--) 的行为；使用 0index 的 for 循环，循环范围 [0,cases)。I64 为正式大驼峰别名，保留 i64 数学缩写；函数/变量小驼峰。GNU bits/stdc++.h 通过 C++17 __has_include 选择，Clang 无此头时 fallback iostream。

光标在 solve 体内，导出为真实 $0。模块 Test.cpp 覆盖空输入、坏输入、最小负数、0/正数并检查返回；Integration.py 把实际 snippet 的 $0 填成读取一个整数/输出二倍的代码，分别核对多 case、未完成输入、空/坏/负/零 case 数，证明 solve 次数/输入消费/光标位置正确。入口各自编译，库共存编译同时覆盖另 49 个模块，不因 main 冲突省略入口验证。

Benchmark 重复读取正数 case header，与旧入口做七轮对照；旧版错误输入不作为性能 baseline。空 solve 可被编译器消去，不用此 smoke 声称循环加速，也不能预测用户 solve 的性能。当前计时见 Performance.md，命令/原始样本见 Results.json。
