#pragma once
#include <bits/stdc++.h>
using i64 = long long;
#include <bits/stdc++.h>

using i64 = long long;

void solve() {
    

    return;
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int t;
    std::cin >> t;

    while (t--) {
        solve();
    }

    return 0;
}
