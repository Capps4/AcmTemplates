#pragma once
#include <algorithm>
#include <cassert>
#include <functional>
#include <limits>
#include <numeric>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

// SNIPPET BEGIN
class SuffixArray {
    template<class Sequence>
    static int checkedSize(const Sequence& sequence) {
        assert(sequence.size() < std::size_t(std::numeric_limits<int>::max()));
        return int(sequence.size());
    }
public:
    const int n;
    std::vector<int> sa, rk, h;
    explicit SuffixArray(const char* text) : SuffixArray(std::string_view(text)) {}
    template<class Sequence, class Compare = std::less<>, class = decltype(std::declval<const Sequence&>().size())>
    explicit SuffixArray(const Sequence& sequence, Compare cmp = {})
        : n(checkedSize(sequence)), sa(n), rk(n), h(n) {
        if (n == 0) return;
        std::vector<int> id(n), nextRank(n), count;
        using Value = std::decay_t<decltype(sequence[0])>;
        constexpr bool byteAlphabet = (std::is_same_v<Value, char> || std::is_same_v<Value, signed char> ||
                                      std::is_same_v<Value, unsigned char>) && std::is_same_v<Compare, std::less<>>;
        auto equivalent = [&](int x, int y) {
            if constexpr (byteAlphabet) return sequence[x] == sequence[y];
            else return !cmp(sequence[x], sequence[y]) && !cmp(sequence[y], sequence[x]);
        };
        if constexpr (byteAlphabet) {
            count.assign(256, 0);
            for (int i = 0; i < n; ++i) ++count[static_cast<unsigned char>(sequence[i])];
            for (int i = 1; i < 256; ++i) count[i] += count[i - 1];
            for (int i = n - 1; i >= 0; --i) sa[--count[static_cast<unsigned char>(sequence[i])]] = i;
        } else {
            std::iota(sa.begin(), sa.end(), 0);
            std::sort(sa.begin(), sa.end(), [&](int x, int y) { return cmp(sequence[x], sequence[y]); });
        }
        int classes = 1;
        rk[sa[0]] = 0;
        for (int i = 1; i < n; ++i) {
            classes += !equivalent(sa[i - 1], sa[i]);
            rk[sa[i]] = classes - 1;
        }
        for (int width = 1; classes < n; width = width >= n - width ? n : 2 * width) {
            int p = 0;
            for (int i = n - width; i < n; ++i) id[p++] = i;
            for (int suffix : sa) if (suffix >= width) id[p++] = suffix - width;
            count.assign(classes, 0);
            for (int suffix : id) ++count[rk[suffix]];
            for (int i = 1; i < classes; ++i) count[i] += count[i - 1];
            for (int i = n - 1; i >= 0; --i) sa[--count[rk[id[i]]]] = id[i];
            int newClasses = 1;
            nextRank[sa[0]] = 0;
            for (int i = 1; i < n; ++i) {
                int x = sa[i - 1], y = sa[i];
                int secondX = width < n - x ? rk[x + width] : -1;
                int secondY = width < n - y ? rk[y + width] : -1;
                newClasses += rk[x] != rk[y] || secondX != secondY;
                nextRank[y] = newClasses - 1;
            }
            rk.swap(nextRank);
            classes = newClasses;
        }
        for (int i = 0, length = 0; i < n; ++i) {
            if (rk[i] == 0) { length = 0; continue; }
            if (length) --length;
            int previous = sa[rk[i] - 1];
            while (length < n - i && length < n - previous && equivalent(i + length, previous + length)) ++length;
            h[rk[i]] = length;
        }
    }
};
