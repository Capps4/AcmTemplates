#pragma once
#include <algorithm>
#include <array>
#include <cassert>
#include <initializer_list>
#include <limits>
#include <string>
#include <string_view>
#include <vector>

// SNIPPET BEGIN
template<int Z, char Base>
class AcAutomaton {
    static_assert(Z > 0 && int(static_cast<unsigned char>(Base)) + Z <= 256);
    static int code(char c) {
        int value = int(static_cast<unsigned char>(c)) - int(static_cast<unsigned char>(Base));
        assert(0 <= value && value < Z);
        return value;
    }
    int insert(std::string_view text) {
        int state = 0;
        for (char c : text) {
            int value = code(c);
            if (!son[state][value]) {
                son[state][value] = ++tot;
                // Initialize a block at a time; avoid touching the unused part
                // of the reserved worst-case table for duplicate patterns.
                if (std::size_t(tot) == son.size()) {
                    auto size = std::min(son.capacity(), son.size() + 1024);
                    son.resize(size);
                    link.resize(size);
                }
            }
            state = son[state][value];
        }
        return state;
    }
    void build() {
        order.reserve(son.size());
        order.push_back(0);
        for (int next : son[0]) if (next) order.push_back(next);
        for (std::size_t i = 1; i < order.size(); ++i) {
            int state = order[i];
            for (int value = 0; value < Z; ++value) {
                int next = son[state][value];
                if (next) {
                    link[next] = son[link[state]][value];
                    order.push_back(next);
                } else son[state][value] = son[link[state]][value];
            }
        }
    }
public:
    std::vector<std::array<int, Z>> son;
    std::vector<int> link, terminal, order;
    int tot = 0;
    AcAutomaton(std::initializer_list<std::string_view> patterns)
        : AcAutomaton(std::vector<std::string_view>(patterns)) {}
    template<class Range>
    explicit AcAutomaton(const Range& patterns) {
        std::size_t sum = 0;
        for (const auto& text : patterns) {
            assert(text.size() <= std::size_t(std::numeric_limits<int>::max() - 1) - sum);
            sum += text.size();
        }
        son.reserve(sum + 1); link.reserve(sum + 1);
        son.emplace_back(); link.push_back(0);
        for (const auto& text : patterns) terminal.push_back(insert(std::string_view(text)));
        son.resize(std::size_t(tot) + 1); link.resize(std::size_t(tot) + 1);
        build();
    }
    std::vector<long long> countOccurrences(std::string_view text) const {
        assert(text.size() < std::size_t(std::numeric_limits<long long>::max()));
        std::vector<long long> visits(son.size());
        visits[0] = 1; // Empty patterns match every boundary, including the first.
        int state = 0;
        for (char c : text) { state = son[state][code(c)]; ++visits[state]; }
        for (std::size_t i = order.size(); i > 1; --i) {
            int node = order[i - 1];
            visits[link[node]] += visits[node];
        }
        std::vector<long long> result;
        result.reserve(terminal.size());
        for (int node : terminal) result.push_back(visits[node]);
        return result;
    }
};
