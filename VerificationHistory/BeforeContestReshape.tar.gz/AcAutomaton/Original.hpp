#pragma once
#include <bits/stdc++.h>
using i64 = long long;
template <int Z, char Base>
class AcAutomaton {
    void insert(int id, const std::string &s) {
        int p = 0;
        for (char c : s) {
            c -= Base;
            if (!son[p][c]) {
                son[p][c] = ++tot;
            }
            p = son[p][c];
        }
        // ID[p].push_back(id);
    }
    void build() {
        std::queue<int> q;
        for (int &y : son[0]) {
            if (y > 0) {
                q.push(y);
            }
        }
        while (!q.empty()) {
            int x = q.front();
            q.pop();

            int c = 0;
            for (int &y : son[x]) {
                if (y) {
                    link[y] = son[link[x]][c];
                    q.push(y);
                } else {
                    y = son[link[x]][c];
                }
                c += 1;
            }
        }
    }

public:
    std::vector<std::array<int, Z>> son{};
    // std::vector<std::vector<int>> ID;
    std::vector<int> link{};
    int tot = 0;

    AcAutomaton(const std::vector<std::string> &s) {
        int sizeSum = 0;
        for (auto t : s) {
            sizeSum += t.size();
        }
        son.resize(sizeSum + 1);
        // ID.resize(sizeSum + 1);
        link.resize(sizeSum + 1);

        for (auto i = 0U; i < s.size(); i++) {
            insert(i, s[i]);
        }
        build();
    }
};

