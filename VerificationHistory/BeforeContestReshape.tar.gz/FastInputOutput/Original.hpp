#pragma once
#include <bits/stdc++.h>
using i64 = long long;
class Qinput {
    static constexpr int BufferSize = 1 << 20;
    FILE* file;
    char buffer[BufferSize + 1];
    char* pos = buffer;
    char* end = buffer;
    bool ended = false, failed = false;

    static bool space(unsigned char c) noexcept {
        return c == ' ' || unsigned(c - '\t') < 5;
    }
    bool refill() noexcept {
        if (ended || failed) return false;
        pos = buffer;
        end = buffer + std::fread(buffer, 1, BufferSize, file);
        *end = 0; // A non-digit sentinel lets the integer loop omit bounds checks.
        if (std::ferror(file)) { failed = true; return false; }
        ended = pos == end;
        return !ended;
    }
    bool ready() noexcept { return pos != end || refill(); }
    bool skip() noexcept {
        if (failed) return false;
        for (;;) {
            while (space(*pos)) ++pos;
            if (pos != end) return true;
            if (!refill()) { failed = true; return false; }
        }
    }
    template<class U, class T>
    Qinput& readInt(T& value) noexcept {
        if (!skip()) return *this;
        bool negative = *pos == '-';
        if (negative || *pos == '+') {
            ++pos;
            if (!ready()) { failed = true; return *this; }
        }
        if (unsigned(*pos - '0') > 9) { failed = true; return *this; }
        U x = 0;
        while (true) {
            while (unsigned(pos[0] - '0') < 10 && unsigned(pos[1] - '0') < 10) {
                x = x * 100 + unsigned(pos[0] - '0') * 10 + unsigned(pos[1] - '0');
                pos += 2;
            }
            if (unsigned(*pos - '0') < 10) x = x * 10 + unsigned(*pos++ - '0');
            if (pos != end || !refill()) break;
        }
        if (!failed) value = T(negative ? U(0) - x : x); // GCC: also handles the signed minimum.
        return *this;
    }
public:
    explicit Qinput(FILE* source = stdin) noexcept : file(source) { buffer[0] = 0; }
    Qinput(const Qinput&) = delete;
    Qinput& operator=(const Qinput&) = delete;
    static Qinput& shared() { static Qinput input; return input; }

    explicit operator bool() const noexcept { return !failed; }
    bool fail() const noexcept { return failed; }
    bool eof() const noexcept { return ended; }
    void clear() noexcept { failed = ended = false; std::clearerr(file); }
    void tie(std::nullptr_t) noexcept {}

    Qinput& operator>>(int& x) noexcept { return readInt<unsigned>(x); }
    Qinput& operator>>(unsigned& x) noexcept { return readInt<unsigned>(x); }
    Qinput& operator>>(long& x) noexcept { return readInt<unsigned long>(x); }
    Qinput& operator>>(unsigned long& x) noexcept { return readInt<unsigned long>(x); }
    Qinput& operator>>(long long& x) noexcept { return readInt<unsigned long long>(x); }
    Qinput& operator>>(unsigned long long& x) noexcept { return readInt<unsigned long long>(x); }
    Qinput& operator>>(__int128& x) noexcept { return readInt<unsigned __int128>(x); }
    Qinput& operator>>(unsigned __int128& x) noexcept { return readInt<unsigned __int128>(x); }
    Qinput& operator>>(char& c) noexcept {
        if (skip()) c = *pos++;
        return *this;
    }
    Qinput& operator>>(std::string& text) {
        if (!skip()) return *this;
        text.clear();
        do {
            const char* first = pos;
            while (pos != end && !space(*pos)) ++pos;
            text.append(first, pos - first);
            if (pos != end) break;
        } while (refill());
        return *this;
    }
    Qinput& getLine(std::string& text, char delimiter = '\n') {
        if (failed) return *this;
        text.clear();
        while (ready()) {
            char* stop = static_cast<char*>(std::memchr(pos, delimiter, end - pos));
            if (stop) {
                text.append(pos, stop - pos);
                pos = stop + 1;
                return *this;
            }
            text.append(pos, end - pos);
            pos = end;
        }
        if (text.empty()) failed = true;
        return *this;
    }
};

class Qoutput {
    static constexpr int BufferSize = 1 << 20;
    FILE* file;
    char buffer[BufferSize];
    int used = 0;
    bool failed = false;

    void drain() noexcept {
        if (used && std::fwrite(buffer, 1, used, file) != unsigned(used)) failed = true;
        used = 0;
    }
    template<class U, class T>
    Qoutput& writeInt(T value) noexcept {
        U x = U(value);
        bool negative = value < 0;
        if (negative) x = U(0) - x;
        char digits[sizeof(T) * 3 + 1];
        char* pos = digits + sizeof(digits);
        static const char pairs[] =
            "0001020304050607080910111213141516171819"
            "2021222324252627282930313233343536373839"
            "4041424344454647484950515253545556575859"
            "6061626364656667686970717273747576777879"
            "8081828384858687888990919293949596979899";
        while (x >= 100) {
            unsigned r = unsigned(x % 100);
            x /= 100;
            pos -= 2;
            std::memcpy(pos, pairs + r * 2, 2);
        }
        if (x < 10) *--pos = char('0' + x);
        else { pos -= 2; std::memcpy(pos, pairs + unsigned(x) * 2, 2); }
        if (negative) *--pos = '-';
        return write(pos, digits + sizeof(digits) - pos);
    }
public:
    explicit Qoutput(FILE* target = stdout) noexcept : file(target) {}
    Qoutput(const Qoutput&) = delete;
    Qoutput& operator=(const Qoutput&) = delete;
    ~Qoutput() { flush(); }
    static Qoutput& shared() { static Qoutput output; return output; }
    explicit operator bool() const noexcept { return !failed; }
    bool fail() const noexcept { return failed; }

    Qoutput& flush() noexcept {
        drain();
        if (std::fflush(file) != 0) failed = true;
        return *this;
    }
    Qoutput& write(const char* data, std::size_t size) noexcept {
        while (size && !failed) {
            if (!used && size >= BufferSize) {
                if (std::fwrite(data, 1, size, file) != size) failed = true;
                break;
            }
            std::size_t room = BufferSize - used;
            std::size_t count = size < room ? size : room;
            std::memcpy(buffer + used, data, count);
            used += int(count);
            data += count;
            size -= count;
            if (used == BufferSize) drain();
        }
        return *this;
    }
    Qoutput& operator<<(int x) noexcept { return writeInt<unsigned>(x); }
    Qoutput& operator<<(unsigned x) noexcept { return writeInt<unsigned>(x); }
    Qoutput& operator<<(long x) noexcept { return writeInt<unsigned long>(x); }
    Qoutput& operator<<(unsigned long x) noexcept { return writeInt<unsigned long>(x); }
    Qoutput& operator<<(long long x) noexcept { return writeInt<unsigned long long>(x); }
    Qoutput& operator<<(unsigned long long x) noexcept { return writeInt<unsigned long long>(x); }
    Qoutput& operator<<(__int128 x) noexcept { return writeInt<unsigned __int128>(x); }
    Qoutput& operator<<(unsigned __int128 x) noexcept { return writeInt<unsigned __int128>(x); }
    Qoutput& operator<<(char c) noexcept {
        if (!failed) {
            buffer[used++] = c;
            if (used == BufferSize) drain();
        }
        return *this;
    }
    Qoutput& operator<<(const char* text) noexcept { return write(text, std::strlen(text)); }
    Qoutput& operator<<(const std::string& text) noexcept { return write(text.data(), text.size()); }
    Qoutput& operator<<(std::ostream& (*fn)(std::ostream&)) noexcept {
        if (fn == std::endl<char, std::char_traits<char>>) { *this << '\n'; flush(); }
        else if (fn == std::flush<char, std::char_traits<char>>) flush();
        else if (fn == std::ends<char, std::char_traits<char>>) *this << '\0';
        else failed = true;
        return *this;
    }
};

#define cin ref(Qinput::shared()).get()
#define cout ref(Qoutput::shared()).get()

