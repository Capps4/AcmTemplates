# FastInputOutput

原来的一兆字节缓冲、哨兵整数读取、双数字读写表、大块写入、getLine 和错误状态设计已相当成熟，保留算法。正式类型为 QInput/QOutput，旧 Qinput/Qoutput 为兼容别名。删除 cin/cout 全局宏（会改写 std::cin、头文件和其他模块），使用 fastIn()/fastOut() 或显式 FILE* 实例。FILE* 借用，调用方保持文件存活至实例析构，输出析构 flush；对象不可复制/移动。

整数普通 operator>> 面向可表示输入，不加每组数字的溢出检查；明确处理有符号最小值，unsigned 拒绝负号。readChecked(T&) 检查每组累加，溢出置 fail 并保留原值；bool 仅接受 0/1，也使用检查路径。失败不能继续读取，clear 清除状态及 FILE 错误，但保留尚未消费的缓冲，不是 seek 操作。字符/字符串跳过 ASCII 空白，getLine 不跳过空白、支持空行和自定义 delimiter（含 NUL）；末尾非空行成功，下一次读取失败。

增加 short/bool、string_view 输出、原生浮点输入、固定格式浮点 writeReal(value,precision)，以及与 FloatPointNumber/Point/ListHelper 的真实接入。浮点以局部 token 和 strto* 解析，token 必须完整；非零 subnormal 接受，无法表示的上下溢失败。使用 C locale。原生浮点输出默认 fixed 6 位，包装 Float 输出按其 setprecision。没有引入完整 iostream 格式状态；std::endl/flush/ends 保留，其他 manipulator 不支持。大精度 writeReal 按实际字符数分配临时缓冲。

测试十万随机及边界整数、128 位最大/最小值、检查溢出/非法 bool/unsigned 负号、符号在缓冲边缘、超一兆字节 token/行、EOF/失败不改原值、标准流逐字输出 oracle、实际读写错误，以及三个模块组合。Buffer 内部范围均半开，下标 0index；类型大驼峰，函数小驼峰，保留少量旧别名。

Benchmark 使用相同 tmpfile 数据、一百万小数值/64 位整数，比较原哨兵内核与最终版普通路径；输出先核对全字节 hash，计时只包括格式化/写入/flush，返回长度避免计时包含第二次读取。此基准不比较新增 readChecked 和浮点路径，也不能代表终端/在线评测 I/O。本轮多数整数场景接近持平，64 位读取约回退 6%；保留内核并明确增加的符号处理，不宣称全场景提速。七轮中位数和编译命令见 Performance.md/Results.json，不把 C++17 语法变化宣称为提速。
