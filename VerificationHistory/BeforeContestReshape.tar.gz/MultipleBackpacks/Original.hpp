#pragma once
#include <bits/stdc++.h>
using i64 = long long;
using VecGood = std::vector<std::array<int, 3>>;
std::vector<long long> multiBag(const VecGood &goods, int S) {
    // S 总背包大小
    std::vector<long long> f(S + 1, 0);
    std::vector<int> q(S + 2, 0);
    for (auto gd : goods) {
        int v = gd[0];
        int w = gd[1];
        int m = gd[2];
        // v价值, w体积, m数量
        auto calc = [&](int i, int j) {
            return f[j] + 1LL * (i - j) / w * v;
        };
        for (int up = S; up + w > S; up--) {
            int l = 1, r = 0, k = up;
            for (int x = up; x > 0; x -= w) {
                for (; k >= std::max(0LL, x - 1LL * m * w); k -= w) {
                    while (l <= r and calc(x, k) > calc(x, q[r])) {
                        r -= 1;
                    }
                    q[++r] = k;
                }
                f[x] = calc(x, q[l]);
                if (q[l] == x) {
                    l += 1;
                }
            }
        }
    }
    return f;
}

