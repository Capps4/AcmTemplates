#pragma once
#include <algorithm>
#include <array>
#include <cassert>
#include <limits>
#include <vector>

// SNIPPET BEGIN
using VecGood = std::vector<std::array<int, 3>>; // {value, weight, count}
inline std::vector<long long> multiBag(const VecGood& goods, int capacity) {
    assert(0 <= capacity && capacity < std::numeric_limits<int>::max());
    std::vector<long long> best(std::size_t(capacity) + 1);
    std::vector<int> queue(std::size_t(capacity) + 2);
    for (const auto& [value, weight, available] : goods) {
        assert(weight >= 0 && available >= 0);
        if (available == 0 || value <= 0) continue;
        if (weight == 0) {
            long long bonus = 1LL * value * available;
            for (auto& result : best) result += bonus;
            continue;
        }
        if (weight > capacity) continue;
        int count = std::min(available, capacity / weight);
        auto score = [&](int target, int source) {
            return best[source] + 1LL * ((target - source) / weight) * value;
        };
        // Descending residue chains preserve unmodified source DP values.
        for (int top = capacity; top > capacity - weight; --top) {
            int first = 1, last = 0, source = top;
            for (int target = top; target > 0; target -= weight) {
                long long lower = std::max(0LL, target - 1LL * count * weight);
                for (; source >= lower; source -= weight) {
                    while (first <= last && score(target, source) > score(target, queue[last])) --last;
                    queue[++last] = source;
                }
                best[target] = score(target, queue[first]);
                if (queue[first] == target) ++first;
            }
        }
    }
    return best;
}
