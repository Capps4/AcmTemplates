#pragma once
#include <algorithm>
#include <cassert>
#include <limits>
#include <string_view>
#include <vector>

// SNIPPET BEGIN
class Manacher {
    const int n;
    std::vector<int> odd, even, tail;
    static int checkedSize(std::string_view text) {
        assert(text.size() <= std::size_t(std::numeric_limits<int>::max()));
        return int(text.size());
    }
public:
    explicit Manacher(std::string_view text) : n(checkedSize(text)), odd(n), even(n), tail(n) {
        for (int i = 0, l = 0, r = -1; i < n; ++i) {
            int radius = i > r ? 1 : std::min(odd[l + (r - i)], r - i + 1);
            while (radius <= i && radius < n - i && text[i - radius] == text[i + radius]) ++radius;
            odd[i] = radius;
            if (i + radius - 1 > r) { l = i - radius + 1; r = i + radius - 1; }
            tail[i + radius - 1] = std::max(tail[i + radius - 1], radius + (radius - 1));
        }
        // even[i] is centered between i-1 and i.
        for (int i = 0, l = 0, r = -1; i < n; ++i) {
            int radius = i > r ? 0 : std::min(even[l + (r - i) + 1], r - i + 1);
            while (radius < i && radius < n - i && text[i - radius - 1] == text[i + radius]) ++radius;
            even[i] = radius;
            if (i + radius - 1 > r) { l = i - radius; r = i + radius - 1; }
            if (radius) tail[i + radius - 1] = std::max(tail[i + radius - 1], 2 * radius);
        }
        for (int i = n - 2; i >= 0; --i) tail[i] = std::max(tail[i], tail[i + 1] - 2);
    }
    // Returns the full length; between=true means the center i+0.5.
    int getPalinLenFromCenter(int i, bool between = false) const {
        assert(i >= 0 && i < n - int(between));
        return between ? 2 * even[i + 1] : odd[i] + (odd[i] - 1);
    }
    int getPalinLenFromTail(int i) const {
        assert(i >= 0 && i < n);
        return tail[i];
    }
    bool isPalindrome(int l, int r) const {
        assert(0 <= l && l <= r && r <= n);
        if (l == r) return true;
        int length = r - l;
        return getPalinLenFromCenter(l + (length - 1) / 2, length % 2 == 0) >= length;
    }
};
