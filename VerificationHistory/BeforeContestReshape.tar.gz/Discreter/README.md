# Discreter

原 snippet 只有 `discreteFrom` 管道，缺少持久化树所引用的 Discreter 类。补齐拥有排序去重值的 `Discreter<T,Compare>`；保留管道，并消除缓存操作重复复制拥有的基准数组。依赖 ListHelper。

```cpp
Discreter disc(std::vector<int>{9, 2, 9});
int rank = disc.rankOf(9); // 1
int end = disc.upperRankOf(9); // 2
std::vector<int> ranks = std::vector<int>{9, 2} | discreteFrom(disc);
```

rankOf 为 lower_bound 插入位置，upperRankOf 为 upper_bound 位置，不要求目标值存在。排序和去重遵循严格弱序比较器等价关系。rank 为 0index，取值范围 `[0,size)`，插入位置允许 size。at 对 lvalue 返回 const 引用，bool 返回值；对临时对象返回拥有的值。比较器必须 const 可调用，支持不可复制比较器。构造 O(n log n)，查找 O(log n)，拥有 vector 右值可移动构造。

`discreteFrom(lvalue)` 借用基准，其寿命覆盖调用；rvalue 基准由操作拥有。传入普通容器必须已按同一比较器排序，管道不为每次调用额外扫描排序性；传入 Discreter 时使用其 rankOf 及内部比较器。不存在的值仍返回插入位置。

测试用标准排序和二分对照千组数据，涵盖空集、重复值、整数极值、降序、bool、CTAD、临时对象取值、借用基准变更、缓存拥有基准与不可复制比较器。

风格自审：Discreter 类型大驼峰，rankOf/upperRankOf 小驼峰，0index 和半开界限明确。没有添加哈希缓存或多余映射层。性能见 [Performance.md](Performance.md)：借用基准场景比较管道，缓存拥有基准场景验证避免复制的收益。
