#include "Final.hpp"
#include "../TestSupport.hpp"
#include <memory>
#include <climits>
int main(){
    Discreter<int> empty;CHECK(empty.size()==0 && empty.rankOf(7)==0 && !empty.contains(7));
    for(int test=0;test<1000;++test){std::vector<int> a(randomInt(0,200));for(auto& x:a)x=randomInt(-100,100);Discreter disc(a);auto expected=a;std::sort(expected.begin(),expected.end());expected.erase(std::unique(expected.begin(),expected.end()),expected.end());CHECK(disc.size()==int(expected.size()));for(int i=0;i<disc.size();++i)CHECK(disc.at(i)==expected[i]);for(int x=-101;x<=101;++x){CHECK(disc.rankOf(x)==int(std::lower_bound(expected.begin(),expected.end(),x)-expected.begin()));CHECK(disc.upperRankOf(x)==int(std::upper_bound(expected.begin(),expected.end(),x)-expected.begin()));CHECK(disc.contains(x)==std::binary_search(expected.begin(),expected.end(),x));}auto ranks=a|discreteFrom(disc);for(std::size_t i=0;i<a.size();++i)CHECK(disc.at(ranks[i])==a[i]);}
    Discreter<long long> limits{LLONG_MIN,LLONG_MAX,0,-1,LLONG_MIN};CHECK(limits.size()==4 && limits.at(0)==LLONG_MIN && limits.upperRankOf(LLONG_MAX)==4);
    auto basis=std::vector<int>{1,3,5};auto op=discreteFrom(basis);std::vector<int> query{0,1,2,5,7};CHECK((query|op)==std::vector<int>({0,0,1,2,3}));basis={0,2,4,6};CHECK((query|op)==std::vector<int>({0,1,1,3,4}));
    auto owned=discreteFrom(std::vector<int>{1,3,5});CHECK((query|owned)==std::vector<int>({0,0,1,2,3}));CHECK((query|owned)==std::vector<int>({0,0,1,2,3}));
    Discreter reversed(std::vector<int>{1,3,5},std::greater<>{});CHECK((query|discreteFrom(reversed))==std::vector<int>({3,2,2,0,0}));
    Discreter<bool> bits(std::vector<bool>{true,false,true});CHECK(bits.size()==2 && !bits.at(0) && bits.at(1));CHECK((std::vector<bool>{true,false}|discreteFrom(bits))==std::vector<int>({1,0}));
    auto cmp=[p=std::make_unique<int>(1)](int a,int b){return a*(*p)<b*(*p);};Discreter<int,decltype(cmp)> moved(std::vector<int>{3,2,3},std::move(cmp));auto moveOnly=discreteFrom(std::move(moved));CHECK((std::vector<int>{2,3}|moveOnly)==std::vector<int>({0,1}));CHECK((std::vector<int>{2,3}|moveOnly)==std::vector<int>({0,1}));
    decltype(auto) fromTemporary=Discreter<std::string>({std::string(1000,'a')}).at(0);static_assert(std::is_same_v<decltype(fromTemporary),std::string>);CHECK(fromTemporary.size()==1000);
    Discreter chars(std::string_view("banana"));CHECK(chars.size()==3);
    std::cout<<"Discreter: sort/lower/upper-bound oracles, CTAD, empty, extremes, owning/borrowed bases, move-only, bool, temporary lifetime PASS\n";
}
