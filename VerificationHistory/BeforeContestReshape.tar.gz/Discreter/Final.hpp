#pragma once
#include <algorithm>
#include <cassert>
#include <functional>
#include <initializer_list>
#include <limits>
#include <tuple>
#include <type_traits>
#include <utility>
#include <vector>
#include "../ListHelper/Final.hpp"

// SNIPPET BEGIN
template<class T, class Compare = std::less<>>
class Discreter {
    std::vector<T> values;
    Compare cmp;
    void build() {
        assert(values.size() < std::size_t(std::numeric_limits<int>::max()));
        std::sort(values.begin(), values.end(), std::ref(cmp));
        values.erase(std::unique(values.begin(), values.end(), [&](const T& a, const T& b) {
            return !cmp(a, b) && !cmp(b, a);
        }), values.end());
    }
public:
    static_assert(std::is_invocable_r_v<bool, const Compare&, const T&, const T&>);
    using value_type = T;
    using ConstReference = std::conditional_t<std::is_same_v<T, bool>, bool, const T&>;
    explicit Discreter(std::vector<T> input = {}, Compare compare = {})
        : values(std::move(input)), cmp(std::move(compare)) { build(); }
    Discreter(std::initializer_list<T> input, Compare compare = {})
        : Discreter(std::vector<T>(input), std::move(compare)) {}
    template<class Range>
    explicit Discreter(const Range& input, Compare compare = {})
        : Discreter(std::vector<T>(input.begin(), input.end()), std::move(compare)) {}
    int size() const { return int(values.size()); }
    int rankOf(const T& value) const {
        return int(std::lower_bound(values.begin(), values.end(), value, std::cref(cmp)) - values.begin());
    }
    int upperRankOf(const T& value) const {
        return int(std::upper_bound(values.begin(), values.end(), value, std::cref(cmp)) - values.begin());
    }
    bool contains(const T& value) const {
        int rank = rankOf(value);
        return rank < size() && !cmp(value, values[rank]);
    }
    ConstReference at(int rank) const & {
        assert(0 <= rank && rank < size());
        if constexpr (std::is_same_v<T, bool>) return bool(values[rank]);
        else return values[rank];
    }
    T at(int rank) const && { return static_cast<const Discreter&>(*this).at(rank); }
    auto begin() const { return values.begin(); }
    auto end() const { return values.end(); }
    const Compare& comparator() const { return cmp; }
};
template<class T, class Compare = std::less<>>
Discreter(std::vector<T>, Compare = {}) -> Discreter<T, Compare>;
template<class Range, class Compare = std::less<>>
Discreter(const Range&, Compare = {}) -> Discreter<typename Range::value_type, Compare>;
namespace discreteDetail {
    template<class> struct IsDiscreter : std::false_type {};
    template<class T, class Compare> struct IsDiscreter<Discreter<T, Compare>> : std::true_type {};
}
// Sorted lvalue bases are borrowed; rvalues are owned by the operation.
template<class List, class Compare = std::less<>>
auto discreteFrom(List&& values, Compare cmp = {}) {
    return seq::Op{[values = std::tuple<List>(std::forward<List>(values)), cmp = std::move(cmp)](const auto& input) mutable {
        const auto& basis = std::get<0>(values);
        assert(basis.size() < std::size_t(std::numeric_limits<int>::max()));
        std::vector<int> result(input.size());
        for (std::size_t i = 0; i < input.size(); ++i) {
            if constexpr (discreteDetail::IsDiscreter<std::decay_t<List>>::value) result[i] = basis.rankOf(seq::listValue(input, i));
            else result[i] = int(std::lower_bound(basis.begin(), basis.end(), seq::listValue(input, i), std::ref(cmp)) - basis.begin());
        }
        return result;
    }};
}
