#pragma once
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstddef>
#include <limits>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

// SNIPPET BEGIN
template<class T>
class Flow {
    static_assert(std::is_arithmetic_v<T> && !std::is_same_v<T, bool>);
    struct Frame { int vertex, incoming; T remaining, sent = 0; };
    std::vector<int> cur, dep, queue;
    std::vector<Frame> frames;
    static int checkedSize(int size) { assert(size >= 0); return size; }
    bool bfs(int source, int sink) {
        dep.assign(n, -1);
        queue.clear();
        queue.reserve(n);
        queue.push_back(source);
        dep[source] = 0;
        for (std::size_t head = 0; head < queue.size(); ++head) {
            int vertex = queue[head];
            for (int id : g[vertex]) {
                const auto& [next, capacity] = adj[id];
                if (capacity <= 0 || dep[next] != -1) continue;
                dep[next] = dep[vertex] + 1;
                if (next == sink) return true;
                queue.push_back(next);
            }
        }
        return false;
    }
    T blockingFlow(int source, int sink, T limit) {
        frames.clear();
        frames.reserve(n);
        frames.push_back({source, -1, limit});
        while (!frames.empty()) {
            auto& frame = frames.back();
            int vertex = frame.vertex;
            auto& cursor = cur[vertex];
            while (frame.remaining > 0 && cursor < int(g[vertex].size())) {
                const auto& [next, capacity] = adj[g[vertex][cursor]];
                if (capacity > 0 && dep[next] == dep[vertex] + 1) break;
                ++cursor;
            }
            if (frame.remaining == 0 || cursor == int(g[vertex].size())) {
                int incoming = frame.incoming;
                T out = frame.sent;
                if (frame.remaining > 0) dep[vertex] = -1;
                frames.pop_back();
                if (frames.empty()) return out;
                adj[incoming].second -= out;
                adj[incoming ^ 1].second += out;
                auto& parent = frames.back();
                parent.remaining -= out;
                parent.sent += out;
                if (parent.remaining > 0) ++cur[parent.vertex];
                continue;
            }
            int id = g[vertex][cursor];
            T out = std::min(frame.remaining, adj[id].second);
            if (adj[id].first == sink) {
                adj[id].second -= out;
                adj[id ^ 1].second += out;
                frame.remaining -= out;
                frame.sent += out;
                if (frame.remaining > 0) ++cursor;
            } else {
                frames.push_back({adj[id].first, id, out});
            }
        }
        return 0;
    }

public:
    static constexpr T Inf = std::numeric_limits<T>::max();
    int n;
    std::vector<std::pair<int, T>> adj;
    std::vector<std::vector<int>> g;
    explicit Flow(int size) : n(checkedSize(size)), g(n) {}
    int newNode() {
        assert(n < std::numeric_limits<int>::max());
        g.emplace_back();
        return n++;
    }
    int add(int source, int target, T capacity, T reverseCapacity = 0) {
        assert(0 <= source && source < n && 0 <= target && target < n);
        assert(capacity >= 0 && reverseCapacity >= 0 && capacity <= Inf - reverseCapacity);
        if constexpr (std::is_floating_point_v<T>) assert(std::isfinite(capacity) && std::isfinite(reverseCapacity));
        assert(adj.size() <= std::size_t(std::numeric_limits<int>::max() - 2));
        int id = int(adj.size());
        g[source].push_back(id); adj.emplace_back(target, capacity);
        g[target].push_back(id + 1); adj.emplace_back(source, reverseCapacity);
        return id;
    }
    // Returns additional flow, modifying residual capacities. Call again to continue.
    T work(int source, int sink, T limit = Inf) {
        assert(0 <= source && source < n && 0 <= sink && sink < n && limit >= 0);
        if (source == sink || limit == 0) return 0;
        T result = 0;
        while (result < limit && bfs(source, sink)) {
            cur.assign(n, 0);
            result += blockingFlow(source, sink, limit - result);
        }
        return result;
    }
    std::string getReach(int source) const {
        assert(0 <= source && source < n);
        std::string reached(n, 't');
        std::vector<int> pending{source};
        reached[source] = 's';
        for (std::size_t head = 0; head < pending.size(); ++head)
            for (int id : g[pending[head]]) {
                const auto& [next, capacity] = adj[id];
                if (capacity > 0 && reached[next] == 't') { reached[next] = 's'; pending.push_back(next); }
            }
        return reached;
    }
    std::vector<std::pair<int, int>> getCuts(int source) const {
        auto reached = getReach(source);
        std::vector<std::pair<int, int>> result;
        for (int vertex = 0; vertex < n; ++vertex) if (reached[vertex] == 's')
            for (int id : g[vertex]) if (reached[adj[id].first] == 't') result.emplace_back(vertex, adj[id].first);
        return result;
    }
};
