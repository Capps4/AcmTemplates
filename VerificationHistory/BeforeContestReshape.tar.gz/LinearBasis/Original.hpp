#pragma once
#include <bits/stdc++.h>
using i64 = long long;
template <class T>
class LinearBasis {
    static constexpr int logn = std::__lg(std::numeric_limits<T>::max());
public:
    std::array<T, logn + 1> b{};
    int rank{}; // 线性基的秩（有效基向量数量）
    bool canZero{};

    LinearBasis() {
        clear();
    }

    void clear() {
        canZero = false;
        dirt = false;
        rank = 0;
        b.fill(0);
    }

    void insert(T x) {
        for (int i = logn; i >= 0; i--) {
            if (x >> i & 1) {
                if (b[i] == 0) {
                    b[i] = x;
                    rank += 1;
                    dirt = true;
                    return;
                }
                x ^= b[i];
            }
        }
        canZero = true;
    }

    // 询问线性基能不能异或出 x
    bool check(T x) {
        for (int i = logn; i >= 0; i--)
            if (x >> i & 1) {
                if (b[i] == 0) {
                    return false;
                }
                x ^= b[i];
            }
        return true;
    }

    // 在线性基中选择一个子集异或，将结果再异或 on 后得到的最大值
    T getMax(T on = 0) {
        T res = on;
        for (int i = logn; i >= 0; i--) {
            // 贪心策略：如果异或当前基能让结果更大，则选择该基
            if (b[i] != 0 && (res ^ b[i]) > res) {
                res ^= b[i];
            }
        }
        return res;
    }

    // 在线性基中选择一个子集异或，将结果再异或 on 后得到的最小值
    T getMin(T on = 0) {
        T res = on;
        for (int i = logn; i >= 0; i--) {
            if (b[i] != 0 && (res >> i & 1)) {
                res ^= b[i];
            }
        }
        return res;
    }

    // 在线性基中选择一个非空子集异或 (可空则注释掉canZero)
    // 查询有 K 个元素比它小的元素
    T findByOrder(T K) {
        if (canZero == false) {
            K += 1;
        }
        build();

        T res = 0;
        int j = 0;
        for (int i = 0; i <= logn; i++) {
            if (b[i] == 0) {
                continue;
            }

            if (K >> j & 1) {
                res ^= b[i];
            }
            j += 1;
        }

        return res;
    }

private:
    bool dirt{};
    void build() {
        if (dirt == false) {
            return;
        }
        for (int i = 1; i <= logn; i++) {
            for (int j = i - 1; j >= 0; j--) {
                if (b[i] >> j & 1) {
                    b[i] ^= b[j];
                }
            }
        }
        dirt = false;
    }
};

