#pragma once
#include <array>
#include <cassert>
#include <limits>
#include <optional>
#include <type_traits>

// SNIPPET BEGIN
template<class T>
class LinearBasis {
    static_assert(std::is_integral_v<T> && !std::is_same_v<T, bool>);
    using Unsigned = std::make_unsigned_t<T>;
    static constexpr int bits = std::numeric_limits<T>::digits;
    static constexpr int unsignedBits = std::numeric_limits<Unsigned>::digits;
    bool dirty = false;
    void build() {
        if (!dirty) return;
        for (int i = 1; i < bits; ++i) for (int j = i - 1; j >= 0; --j)
            if ((Unsigned(b[i]) >> j) & 1) b[i] ^= b[j];
        dirty = false;
    }
public:
    std::array<T, bits> b{};
    int rank = 0;
    bool canZero = false; // A nonempty subset can produce zero.
    LinearBasis() = default;
    void clear() { b.fill(0); rank = 0; canZero = dirty = false; }
    void insert(T value) {
        if constexpr (std::is_signed_v<T>) assert(value >= 0);
        for (int i = bits - 1; i >= 0; --i) if ((Unsigned(value) >> i) & 1) {
            if (!b[i]) { b[i] = value; ++rank; dirty = true; return; }
            value ^= b[i];
        }
        canZero = true;
    }
    bool check(T value) const {
        if constexpr (std::is_signed_v<T>) if (value < 0) return false;
        for (int i = bits - 1; i >= 0; --i) if ((Unsigned(value) >> i) & 1) {
            if (!b[i]) return false;
            value ^= b[i];
        }
        return true;
    }
    T getMax(T initial = 0) const {
        if constexpr (std::is_signed_v<T>) assert(initial >= 0);
        for (int i = bits - 1; i >= 0; --i) if (b[i] && (initial ^ b[i]) > initial) initial ^= b[i];
        return initial;
    }
    T getMin(T initial = 0) const {
        if constexpr (std::is_signed_v<T>) assert(initial >= 0);
        for (int i = bits - 1; i >= 0; --i) if (b[i] && ((Unsigned(initial) >> i) & 1)) initial ^= b[i];
        return initial;
    }
    // Distinct sorted XOR values; index 0 is smallest. Empty subset is optional.
    std::optional<T> kth(Unsigned index, bool includeEmpty = false) {
        if (!includeEmpty && !canZero) {
            if (index == std::numeric_limits<Unsigned>::max()) return std::nullopt;
            ++index;
        }
        if (rank < unsignedBits && index >= (Unsigned(1) << rank)) return std::nullopt;
        build();
        T result = 0;
        int position = 0;
        for (int i = 0; i < bits; ++i) if (b[i]) {
            if ((index >> position) & 1) result ^= b[i];
            ++position;
        }
        return result;
    }
    T findByOrder(Unsigned index) {
        auto result = kth(index);
        assert(result.has_value());
        return *result;
    }
};
