# LinearBasis

使用 numeric_limits::digits 替代 GNU 内部 __lg 定义位数；补充 const 查询和返回 optional 的 kth，处理空基、非空子集与满 64 位秩的排序边界。原 findByOrder 仍返回值，要求合法 k，并通过断言检查。

```cpp
LinearBasis<unsigned long long> basis;
basis.insert(3); basis.insert(5);
auto third = basis.kth(2);       // 非空子集的不同 XOR 值：3,5,6
bool missing = !basis.kth(3);
auto zero = basis.kth(0, true); // 包括空子集：0,3,5,6
```

支持非 bool 标准整数类型，signed 输入和 getMax/getMin 初值要求非负；需要最高符号位按比特处理时使用 unsigned 类型。check(0) 总为 true（可选空子集），canZero 表示存在非空子集 XOR 为零。k 为 0index，不同 XOR 结果按数值排序，不统计多个子集产生同值的重复次数。kth 默认排除空子集，includeEmpty=true 包含；没有答案返回 nullopt。参数类型为 T 的对应 unsigned 类型，避免 K+1 的 signed 溢出；满 64 位秩时不计算 1<<64，也不让最大索引自增回绕。

b/rank/canZero 保留原公开字段供观察；调用方不应直接修改它们。构造直接零初始化，clear 可重置；build 的 RREF 可在之后继续 insert。insert/check/getMax/getMin 与排序查询 O(bits)，第一次排序准备 O(bits²)，空间 O(bits)。保留跳过空基向量的快路径，随机高位初值配合稀疏基时它明显减少无效分支。

测试对千组 <=11 个输入枚举全部子集，核对可表示值、非空零、秩、带初值 min/max、不同值 kth；每次插入间执行 build，再测 full uint64、signed 63 位和 unsigned char 上界。性能见 [Performance.md](Performance.md)，有效输入与原版对照，边界修复不宣称算法加速。

风格自审：LinearBasis 大驼峰，小驼峰方法/变量，既有 getMax/getMin/findByOrder 保留；0index 排序、位范围 `[0,bits)` 与非空契约明确，没有持久化副本或不必要包装。

当前三项性能接近旧版（约 0%~4% 回退），收益主要是满位秩/越界处理、const 查询及标准位宽定义。
