#pragma once
#include <bits/stdc++.h>
using i64 = long long;
class GridUtil {
    static constexpr int D = 4;
    static constexpr int dx[D] = {0, 0, -1, 1};
    static constexpr int dy[D] = {-1, 1, 0, 0};

public:
    int n, m;
    GridUtil(int n, int m) : n{n}, m{m} {}

    bool contains(int x, int y) const {
        return 0 <= x and x < n and 0 <= y and y < m;
    }

    std::vector<std::pair<int, int>> neighbors(int x, int y) const {
        assert(contains(x, y));
        std::vector<std::pair<int, int>> neibrs;
        neibrs.reserve(D);
        for (int k = 0; k < D; k++) {
            int nx = x + dx[k];
            int ny = y + dy[k];
            if (contains(nx, ny)) {
                neibrs.emplace_back(nx, ny);
            }
        }
        return neibrs;
    }
};

