#include "Final.hpp"
#include "../TestSupport.hpp"
#include <memory>
template<class Seq,class Compare>
std::size_t naive(const Seq& input,Compare less){
    std::size_t best=0,n=input.size();
    for(std::size_t candidate=1;candidate<n;++candidate){for(std::size_t k=0;k<n;++k){auto a=input[(candidate+k)%n],b=input[(best+k)%n];if(less(a,b)){best=candidate;break;}if(less(b,a))break;}}
    return best;
}
void verify(const std::string& input){
    auto less=[](char a,char b){return static_cast<unsigned char>(a)<static_cast<unsigned char>(b);};
    auto index=naive(input,less);CHECK(minimalRotationIndex(input)==index);CHECK(minimalRotationIndex(std::string_view(input))==index);
    auto expected=input;std::rotate(expected.begin(),expected.begin()+index,expected.end());
    CHECK((input|minimalString())==expected);CHECK((std::string_view(input)|minimalString())==expected);CHECK((std::string(input)|minimalString())==expected);
}
struct Record{int key;};
int main(){
    for(int n=0;n<=12;++n)for(int mask=0;mask<(1<<n);++mask){std::string s(n,'a');for(int i=0;i<n;++i)s[i]+=bool(mask&(1<<i));verify(s);}
    for(int test=0;test<1000;++test){std::string s(randomInt(0,100),'\0');for(auto& c:s)c=char(randomInt(0,255));verify(s);}
    CHECK(minimalRotationIndex("baba")==1);CHECK(minimalRotationIndex("aaaa")==0);
    std::vector<int> values{5,-1,0,-1};auto index=naive(values,std::greater<>{});CHECK(minimalRotationIndex(values,std::greater<>{})==index);auto expected=values;std::rotate(expected.begin(),expected.begin()+index,expected.end());CHECK((values|minimalString(std::greater<>{}))==expected);
    std::vector<bool> bits{true,false,true,false};CHECK(minimalRotationIndex(bits)==1);CHECK((bits|minimalString())==std::vector<bool>({false,true,false,true}));
    std::vector<Record> records{{5},{1},{2},{1}};auto cmp=[p=std::make_unique<int>(1)](const Record& a,const Record& b){return a.key*(*p)<b.key*(*p);};auto operation=minimalString(std::move(cmp));auto rotated=records|operation;CHECK(rotated[0].key==1 && rotated[1].key==2 && rotated[2].key==1 && rotated[3].key==5);CHECK((records|operation)[0].key==1);
    std::string repeated(1000000,'x');CHECK(minimalRotationIndex(repeated)==0);
    std::cout<<"MinimalString: exhaustive rotations, periodic tie index, arbitrary bytes/views, custom move-only comparator, proxies PASS\n";
}
