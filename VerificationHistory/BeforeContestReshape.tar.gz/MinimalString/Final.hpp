#pragma once
#include <algorithm>
#include <functional>
#include <type_traits>
#include "../ListHelper/Final.hpp"

// SNIPPET BEGIN
template<class Sequence, class Compare = std::less<>, class = decltype(std::declval<const Sequence&>().size())>
std::size_t minimalRotationIndex(const Sequence& input, Compare cmp = {}) {
    const auto n = input.size();
    std::size_t i = 0, j = 1, matched = 0;
    using Value = typename Sequence::value_type;
    constexpr bool byteOrder = (std::is_same_v<Value, char> || std::is_same_v<Value, signed char> ||
                               std::is_same_v<Value, unsigned char>) &&
                              (std::is_same_v<Compare, std::less<>> || std::is_same_v<Compare, std::reference_wrapper<std::less<>>>);
    auto less = [&](const auto& a, const auto& b) {
        if constexpr (byteOrder) return static_cast<unsigned char>(a) < static_cast<unsigned char>(b);
        else return std::invoke(cmp, a, b);
    };
    auto offset = [n](std::size_t start, std::size_t distance) {
        return start < n - distance ? start + distance : start - (n - distance);
    };
    while (matched < n && i < n && j < n) {
        decltype(auto) left = seq::listValue(input, offset(i, matched));
        decltype(auto) right = seq::listValue(input, offset(j, matched));
        bool smaller = less(left, right), larger = less(right, left);
        if (!smaller && !larger) { ++matched; continue; }
        auto& candidate = smaller ? j : i;
        candidate = matched >= n - candidate - 1 ? n : candidate + matched + 1;
        if (i == j) ++i;
        matched = 0;
    }
    return std::min(i, j);
}
template<class Compare = std::less<>>
std::size_t minimalRotationIndex(const char* text, Compare cmp = {}) {
    return minimalRotationIndex(std::string_view(text), std::move(cmp));
}
template<class Compare = std::less<>>
auto minimalString(Compare cmp = {}) {
    return seq::Op{[cmp = std::move(cmp)](auto&& input) mutable {
        auto result = seq::materialize(std::forward<decltype(input)>(input));
        if (!result.empty()) {
            auto index = minimalRotationIndex(result, std::ref(cmp));
            std::rotate(result.begin(), result.begin() + index, result.end());
        }
        return result;
    }};
}
