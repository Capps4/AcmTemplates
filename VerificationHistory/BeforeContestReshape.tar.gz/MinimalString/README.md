# MinimalString

依赖 ListHelper。保留线性最小表示法，用一次回绕替代热循环的取模；加入直接返回位置的 `minimalRotationIndex`，无需复制或旋转输入。`minimalString()` 管道返回拥有的容器，lvalue 复制、rvalue 移动、string_view 转为 string。

```cpp
auto pos = minimalRotationIndex(std::string_view("baca")); // 3
auto text = std::string_view("baca") | minimalString(); // "abac"
```

下标 0index，周期性相同最小旋转返回最小位置，空输入返回 0。比较器须为严格弱序；按双向比较判等，不要求元素 operator==。默认 char/signed char/unsigned char 采用无符号字节顺序，可处理内嵌 NUL；C 字符串重载依其长度而不包含终止 NUL。自定义比较器按自身顺序，缓存管道支持不可复制比较器。接口要求可按下标访问的序列；最小表示法 O(n)，原地旋转 O(n)。

测试遍历二元字符串长度 0..12 的所有旋转，与朴素枚举比较；另测随机全部字节、周期相同值、降序、bool、记录类型、缓存不可复制比较器和百万长度。

风格自审：PascalCase 比较器类型，小驼峰函数；返回的是 0index 旋转起点，输出范围 `[0,n)`。未引入独立算法框架。性能见 [Performance.md](Performance.md)，旧版对照限于其支持的小写 ASCII 输入。

较早复测中全相同字母曾慢约 5%，新复测的倍率不同；二元与 26 字母也随状态波动，以 Performance.md 当前原始数据为准。直接查询位置可避免整个结果容器，但不与旧旋转管道混作同一基准。
