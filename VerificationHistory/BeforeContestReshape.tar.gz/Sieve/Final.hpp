#pragma once
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <limits>
#include <type_traits>
#include <vector>

// SNIPPET BEGIN
class Sieve {
    std::vector<int> minPrimeFactor, primeList;
public:
    // The table covers [0, n); mpf(x) grows it automatically to cover x.
    explicit Sieve(std::size_t n = 0) { init(n); }
    static Sieve& shared(std::size_t n = 128) {
        static Sieve instance;
        instance.init(n);
        return instance;
    }
    void init(std::size_t n) {
        if (n <= size()) return;
        constexpr auto maxSize = std::size_t(std::numeric_limits<int>::max()) + 1;
        assert(n <= maxSize);
        n = std::max(n, std::min(maxSize, 2 * size()));
        minPrimeFactor.assign(n, 0);
        primeList.clear();
        primeList.reserve(n / 10);
        for (std::size_t i = 2; i < n; ++i) {
            if (!minPrimeFactor[i]) {
                primeList.push_back(int(i));
                minPrimeFactor[i] = int(i);
            }
            for (int p : primeList) {
                auto product = std::uint64_t(i) * p;
                if (product >= n) break;
                minPrimeFactor[std::size_t(product)] = p;
                if (p == minPrimeFactor[i]) break;
            }
        }
    }
    std::size_t size() const { return minPrimeFactor.size(); }
    int mpf(std::size_t x) {
        assert(x <= std::size_t(std::numeric_limits<int>::max()));
        if (x >= size()) init(x + 1);
        return minPrimeFactor[x];
    }
    const std::vector<int>& primes() const { return primeList; }
    template<class T>
    std::vector<std::pair<T, int>> primeFactorize(T x) const {
        static_assert(std::is_integral_v<T> && !std::is_same_v<T, bool> && sizeof(T) <= 8);
        assert(x >= 1);
        std::uint64_t remaining = std::uint64_t(x);
        std::vector<std::pair<T, int>> factors;
        auto process = [&](std::uint64_t p) {
            int count = 0;
            do { remaining /= p; ++count; } while (remaining % p == 0);
            factors.emplace_back(T(p), count);
        };
        // Only trial-divide until the remainder fits the precomputed table.
        for (int p : primeList) {
            if (remaining < size() || std::uint64_t(p) > remaining / p) break;
            if (remaining % p == 0) process(p);
        }
        // All smaller primes were tested; fallback supports an empty/small table.
        for (std::uint64_t d = std::max<std::uint64_t>(2, size());
             remaining >= size() && d <= remaining / d; ++d) {
            if (remaining % d == 0) process(d);
        }
        while (remaining > 1 && remaining < size()) {
            process(minPrimeFactor[std::size_t(remaining)]);
        }
        if (remaining > 1) factors.emplace_back(T(remaining), 1);
        return factors;
    }
    template<class T, std::enable_if_t<std::is_integral_v<T>, int> = 0>
    std::vector<T> allFactors(T x) const { return allFactors(primeFactorize(x)); }
    template<class T>
    static std::vector<T> allFactors(const std::vector<std::pair<T, int>>& factors) {
        std::vector<T> divisors{T(1)};
        for (const auto& [prime, count] : factors) {
            auto oldSize = divisors.size();
            T power = 1;
            for (int exponent = 1; exponent <= count; ++exponent) {
                power *= prime;
                for (std::size_t i = 0; i < oldSize; ++i) divisors.push_back(divisors[i] * power);
            }
        }
        return divisors;
    }
};
inline auto& siv = Sieve::shared(10000);
