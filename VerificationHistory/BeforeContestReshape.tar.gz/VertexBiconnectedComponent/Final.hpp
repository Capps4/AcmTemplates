#pragma once
#include <algorithm>
#include <cassert>
#include <cstddef>
#include <limits>
#include <vector>

// SNIPPET BEGIN
class VertexBc {
public:
    std::vector<int> dfn, low;
    std::vector<std::vector<int>> csqt;
    std::vector<bool> isCut;
    int componentNum = 0;
    explicit VertexBc(const std::vector<std::vector<int>>& adj)
        : dfn(adj.size(), -1), low(adj.size()), isCut(adj.size()) {
        assert(adj.size() <= std::size_t(std::numeric_limits<int>::max()));
        int n = int(adj.size());
        csqt.reserve(std::size_t(n) * 2);
        csqt.resize(n);
        struct Frame { int vertex, skipParent; std::size_t next = 0; };
        std::vector<Frame> frames;
        std::vector<int> active;
        frames.reserve(n);
        active.reserve(n);
        int clock = 0;
        auto enter = [&](int vertex, int parent) {
            dfn[vertex] = low[vertex] = clock++;
            active.push_back(vertex);
            frames.push_back({vertex, parent});
        };
        for (int root = 0; root < n; ++root) {
            if (dfn[root] != -1) continue;
            ++componentNum;
            enter(root, -1);
            while (!frames.empty()) {
                auto& frame = frames.back();
                int vertex = frame.vertex;
                if (frame.next < adj[vertex].size()) {
                    int next = adj[vertex][frame.next++];
                    assert(0 <= next && next < n);
                    if (next == frame.skipParent) { frame.skipParent = -1; continue; }
                    if (dfn[next] == -1) enter(next, vertex);
                    else low[vertex] = std::min(low[vertex], dfn[next]);
                    continue;
                }
                frames.pop_back();
                int parent = frames.empty() ? -1 : frames.back().vertex;
                if (parent == -1) { active.pop_back(); continue; }
                low[parent] = std::min(low[parent], low[vertex]);
                if (low[vertex] >= dfn[parent]) {
                    assert(csqt.size() < std::size_t(std::numeric_limits<int>::max()));
                    int block = int(csqt.size());
                    csqt.emplace_back();
                    int next;
                    do {
                        next = active.back();
                        active.pop_back();
                        csqt[next].push_back(block);
                        csqt[block].push_back(next);
                    } while (next != vertex);
                    csqt[parent].push_back(block);
                    csqt[block].push_back(parent);
                }
            }
        }
        for (int vertex = 0; vertex < n; ++vertex) isCut[vertex] = csqt[vertex].size() > 1;
    }
};
using VertexBC = VertexBc;
