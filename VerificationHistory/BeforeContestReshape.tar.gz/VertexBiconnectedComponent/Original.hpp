#pragma once
#include <bits/stdc++.h>
using i64 = long long;
class VertexBC {
    const int n;
    const std::vector<std::vector<int>> &adj;
    std::stack<int, std::vector<int>> q{};
    int cur = 0, sqid;

    void dfs(int x, int root) {
        dfn[x] = low[x] = cur++;
        q.push(x);

        for (int y : adj[x]) {
            if (dfn[y] == -1) {
                dfs(y, root);
                low[x] = std::min(low[x], low[y]);

                if (low[y] == dfn[x]) {
                    csqt.push_back({});
                    for (int z = -1; z != y; q.pop()) {
                        z = q.top();
                        csqt[z].push_back(sqid);
                        csqt[sqid].push_back(z);
                    }
                    csqt[x].push_back(sqid);
                    csqt[sqid].push_back(x);
                    sqid += 1;
                }
            } else {
                low[x] = std::min(low[x], dfn[y]);
            }
        }
    }

public:
    // original graph
    std::vector<int> dfn, low;
    std::vector<std::vector<int>> csqt; // 圆方树
    int componentNum = 0;

    VertexBC(const std::vector<std::vector<int>> &adj)
        : n(adj.size()),
          adj(adj),
          sqid{n},
          dfn(n, -1),
          low(n),
          csqt(n)
           {

        for (int i = 0; i < n; i++) {
            if (dfn[i] == -1) {
                componentNum += 1;
                dfs(i, i);
                q.pop();
            }
        }
    }
};

