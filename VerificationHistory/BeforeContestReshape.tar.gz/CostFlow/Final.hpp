#pragma once
#include <algorithm>
#include <cassert>
#include <deque>
#include <functional>
#include <limits>
#include <queue>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

// SNIPPET BEGIN
enum CostFlowMode {
    MAX_FLOW_MIN_COST,
    MIN_COST_MAX_FLOW,
    MIN_COST_MIN_FLOW
};

template <class Cap, class Fee>
class CostFlow {
    static_assert(std::is_integral_v<Cap> && !std::is_same_v<Cap, bool> && sizeof(Cap) <= 8,
                  "CostFlow needs integral capacities up to 64 bits");
    static_assert(std::is_integral_v<Fee> && std::is_signed_v<Fee> && sizeof(Fee) <= 8,
                  "CostFlow needs signed integral fees up to 64 bits");
    using Wide = __int128_t;
    static constexpr Wide Inf = Wide(1) << 126;

    struct Edge { int to; Cap cap; Fee fee; };

    // Rebuild on every call: residual reverse arcs and newly added edges may be negative.
    void initPotential(int source) {
        pot.assign(n, 0);
        bool negative = false;
        for (const auto& arc : edge) negative |= arc.cap > 0 && arc.fee < 0;
        if (!negative) return;
        dist.assign(n, Inf);
        dist[source] = 0;
        std::deque<int> queue{source};
        std::vector<bool> queued(n, false);
        std::vector<int> length(n, 0);
        queued[source] = true;
        while (!queue.empty()) {
            int x = queue.front();
            queue.pop_front();
            queued[x] = false;
            for (int index : adj[x]) {
                const auto& arc = edge[index];
                int y = arc.to;
                if (arc.cap == 0 || dist[y] <= dist[x] + arc.fee) continue;
                dist[y] = dist[x] + arc.fee;
                length[y] = length[x] + 1;
                if (length[y] >= n) throw std::domain_error("CostFlow: reachable negative cycle");
                if (!queued[y]) {
                    queue.push_back(y);
                    queued[y] = true;
                }
            }
        }
        for (int x = 0; x < n; ++x) if (dist[x] != Inf) pot[x] = dist[x];
    }

    bool dijkstra(int source, int target) {
        dist.assign(n, Inf);
        pre.assign(n, -1);
        using Entry = std::pair<Wide, int>;
        std::priority_queue<Entry, std::vector<Entry>, std::greater<Entry>> queue;
        dist[source] = 0;
        queue.emplace(0, source);
        while (!queue.empty()) {
            auto [distance, x] = queue.top();
            queue.pop();
            if (distance != dist[x]) continue;
            for (int index : adj[x]) {
                const auto& arc = edge[index];
                if (arc.cap == 0) continue;
                Wide reduced = Wide(arc.fee) + pot[x] - pot[arc.to];
                assert(reduced >= 0);
                Wide candidate = distance + reduced;
                if (candidate < dist[arc.to]) {
                    dist[arc.to] = candidate;
                    pre[arc.to] = index;
                    queue.emplace(candidate, arc.to);
                }
            }
        }
        return dist[target] != Inf;
    }

public:
    const int n;
    std::vector<Edge> edge{};
    std::vector<std::vector<int>> adj;
    std::vector<Wide> pot{}, dist{};
    std::vector<int> pre{};

    explicit CostFlow(int n) : n(n), adj(std::size_t(std::max(n, 0))) {
        if (n < 0) throw std::invalid_argument("CostFlow: negative vertex count");
    }

    void add(int x, int y, Cap cap, Fee fee) {
        assert(0 <= x && x < n && 0 <= y && y < n);
        if (cap < 0 || fee == std::numeric_limits<Fee>::min())
            throw std::invalid_argument("CostFlow: invalid capacity or unnegatable fee");
        if (edge.size() > std::size_t(std::numeric_limits<int>::max() - 2))
            throw std::length_error("CostFlow: too many arcs");
        int index = int(edge.size());
        adj[x].push_back(index);
        edge.push_back({y, cap, fee});
        adj[y].push_back(index + 1);
        edge.push_back({x, 0, Fee(-fee)});
    }

    // Additional flow/cost only. Capacities remain in the residual network.
    template <CostFlowMode mode = MAX_FLOW_MIN_COST>
    std::pair<Cap, Fee> work(int source, int target, Cap limit = std::numeric_limits<Cap>::max()) {
        static_assert(mode == MAX_FLOW_MIN_COST || mode == MIN_COST_MAX_FLOW || mode == MIN_COST_MIN_FLOW);
        assert(0 <= source && source < n && 0 <= target && target < n);
        if (limit < 0) throw std::invalid_argument("CostFlow: negative flow limit");
        if (source == target || limit == 0) return {0, 0};
        Cap flow = 0;
        Fee cost = 0;
        initPotential(source);
        while (flow < limit && dijkstra(source, target)) {
            for (int x = 0; x < n; ++x) if (dist[x] != Inf) pot[x] += dist[x];
            Wide price = pot[target] - pot[source];
            if constexpr (mode == MIN_COST_MAX_FLOW) { if (price > 0) break; }
            if constexpr (mode == MIN_COST_MIN_FLOW) { if (price >= 0) break; }
            Cap aug = limit - flow;
            for (int x = target; x != source; x = edge[pre[x] ^ 1].to)
                aug = std::min(aug, edge[pre[x]].cap);
            Wide delta, nextCost;
            if (__builtin_mul_overflow(Wide(aug), price, &delta) ||
                __builtin_add_overflow(Wide(cost), delta, &nextCost) ||
                nextCost < std::numeric_limits<Fee>::min() || nextCost > std::numeric_limits<Fee>::max())
                throw std::overflow_error("CostFlow: result cost does not fit Fee");
            for (int x = target; x != source; x = edge[pre[x] ^ 1].to) {
                edge[pre[x]].cap -= aug;
                edge[pre[x] ^ 1].cap += aug;
            }
            flow += aug;
            cost = Fee(nextCost);
        }
        return {flow, cost};
    }
};
