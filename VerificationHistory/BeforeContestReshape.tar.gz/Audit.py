"""Audit delivery files and verification freshness, without running algorithms."""
import hashlib
import json
from pathlib import Path
from Export import ROOT, CURSOR, header_body, expand
from Run import check_samples, performance_text

def audit(module):
    directory = ROOT / module
    required = ['Final.hpp', 'Final.code-snippets', 'Test.cpp', 'Benchmark.cpp',
                'README.md', 'Results.json', 'Benchmark.csv']
    for name in required:
        assert (directory / name).is_file(), f'{module}: missing {name}'
    report = json.loads((directory / 'Results.json').read_text())
    for name, digest in report['sha256'].items():
        assert hashlib.sha256((directory / name).read_bytes()).hexdigest() == digest, f'{module}: stale {name}'
    for name, digest in {**report.get('dependencySha256', {}), **report.get('supportSha256', {}), **report.get('includeSha256', {})}.items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, f'{module}: stale dependency {name}'
    manifest = {item['module']: item for item in json.loads((ROOT / 'Manifest.json').read_text())}
    def check_dependencies(name, seen):
        for dependency in manifest[name]['dependencies']:
            if dependency not in seen:
                seen.add(dependency)
                assert f'{dependency}/Final.hpp' in report.get('dependencySha256', {}), f'{module}: missing dependency evidence'
                check_dependencies(dependency, seen)
    check_dependencies(module, set())
    body = next(iter(json.loads((directory / 'Final.code-snippets').read_text()).values()))['body']
    source = header_body(module)
    expanded = expand(body, CURSOR in source, restore_cursor=True)
    assert sum(line.strip() == '$0' for line in body) == 1 and source == expanded, f'{module}: snippet differs from header'
    assert len(report['tests']) == 2 and all(item['output'] for item in report['tests']), module
    for source in directory.glob('TestExtra*.cpp'):
        assert source.name in report['sha256'], f'{module}: missing extra source hash'
        assert all(str(source) in item['command'] for item in report['tests']), f'{module}: extra source was not compiled'
    for source in directory.glob('TestCase*.cpp'):
        assert source.name in report['sha256'], f'{module}: missing independent case hash'
        for item in report['tests']:
            matches = [case for case in item.get('additionalCases', []) if str(source) in case['command']]
            assert len(matches) == 1 and matches[0]['output'], f'{module}: independent case was not compiled/run'
    assert report['benchmark'], module
    assert (directory / 'Benchmark.csv').read_text().split('\n', 1)[1].strip() == report['benchmark'], module
    assert report.get('formatVersion') == 2, f'{module}: benchmark report needs current timing method'
    check_samples(report['benchmark'], report['benchmarkSamples'])
    assert (directory / 'Performance.md').read_text() == performance_text(report), f'{module}: stale performance report'
    assert set(report['supportSha256']) == {'TestSupport.hpp', 'BenchmarkSupport.hpp'}
    return report

if __name__ == '__main__':
    geometry = ROOT / 'GeometryCompatibility'
    if (geometry / 'Sources.json').exists():
        for item in json.loads((geometry / 'Sources.json').read_text()):
            snapshot = geometry / (item['module'] + '.code-snippets')
            assert hashlib.sha256(Path(item['source']).read_bytes()).hexdigest() == item['sha256']
            assert hashlib.sha256(snapshot.read_bytes()).hexdigest() == item['sha256']
            body = next(iter(json.loads(snapshot.read_text()).values()))['body']
            expanded = '\n'.join(body).replace('\\$', '$').replace('\\\\', '\\').replace('$0', '')
            assert (geometry / (item['module'] + '.hpp')).read_text() == '#pragma once\n' + expanded + '\n'
    manifest = json.loads((ROOT / 'Manifest.json').read_text())
    for item in manifest:
        directory = ROOT / item['module']
        assert hashlib.sha256((directory / 'Original.code-snippets').read_bytes()).hexdigest() == item['originalSha256']
        expected_source = item.get('observedSourceSha256', item['originalSha256'])
        assert hashlib.sha256(Path(item['source']).read_bytes()).hexdigest() == expected_source, f"{item['module']}: unreviewed original VS Code snippet change"
        if 'observedSourceSha256' in item:
            assert hashlib.sha256((directory / 'CurrentSource.code-snippets').read_bytes()).hexdigest() == expected_source
        if item['status'] == 'verified':
            audit(item['module'])
            print(item['module'] + ': delivery and verification hashes CURRENT')
    if (ROOT / 'Integration/Results.json').exists():
        from Integration import audit as audit_integration
        audit_integration()
        print('Exported snippets: cross-module integration CURRENT')
    if (ROOT / 'Package.json').exists():
        records = json.loads((ROOT / 'Package.json').read_text())
        assert {item['module'] for item in records} == {item['module'] for item in manifest if item['status'] == 'verified'}
        destination = ROOT / 'ReadyToInstall'
        assert {path.name for path in destination.glob('*.code-snippets')} == {item['file'] for item in records}
        for item in records:
            content = (destination / item['file']).read_bytes()
            assert content == (ROOT / item['module'] / 'Final.code-snippets').read_bytes()
            assert hashlib.sha256(content).hexdigest() == item['sha256']
        print('ReadyToInstall package: exact final snippet copies CURRENT')
    print(f"{sum(item['status'] == 'verified' for item in manifest)}/{len(manifest)} modules verified; Geo2/Geo3 excluded")
