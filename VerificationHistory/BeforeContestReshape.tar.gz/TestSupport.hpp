#pragma once
#include <cstdlib>
#include <iostream>
#include <random>

inline std::mt19937_64 testRng(20261001);
inline int randomInt(int l, int r) {
    return std::uniform_int_distribution<int>(l, r)(testRng);
}
inline void check(bool passed, const char* expression, int line) {
    if (!passed) {
        std::cerr << "Failed at line " << line << ": " << expression << '\n';
        std::exit(1);
    }
}
#define CHECK(...) check(bool((__VA_ARGS__)), #__VA_ARGS__, __LINE__)
