#pragma once

// SNIPPET BEGIN
#if __has_include(<bits/stdc++.h>)
#include <bits/stdc++.h>
#else
#include <iostream>
#endif

using I64 = long long;
using i64 = I64;

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    // SNIPPET CURSOR

    return 0;
}
