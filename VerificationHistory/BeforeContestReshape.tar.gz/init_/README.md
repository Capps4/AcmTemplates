# init_

原入口已经是可用 C++17：sync_with_stdio(false)、cin.tie(nullptr)、明确 return 0，保留这些设置，不为了语法升级增加框架。用 C++17 __has_include，在 GNU 环境采用 bits/stdc++.h，无此头的 Clang 采用 iostream（插入其他库时仍需它们的标准头）。增加正式类型别名 I64，保留常用数学缩写 i64。类型大驼峰、变量/函数小驼峰；main 是语言接口，无索引/区间 API。

光标在 main 体内，源文件的 SNIPPET CURSOR 注释由 Export.py 变为真实 $0。Audit.py 把光标还原成注释核对源码一致，Integration.py 实际在 $0 插入读取/输出代码并单独编译/运行，避免将两个 main 拼进库测试。模块 Test.cpp 检查真实入口设置和返回值；Benchmark 重复 settings 调用作性能 smoke，对一次进程启动没有统计意义，不宣称提速。七轮记录见 Performance.md/Results.json。
