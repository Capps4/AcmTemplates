#pragma once
#include <bits/stdc++.h>
using i64 = long long;
using u64 = unsigned long long;

template <int D, const int *B, const int *P>
class StringHashImpl {
    static_assert(D > 0, "0 hash is prohibit");
    std::vector<std::array<int, D>> h;
public:
    template <class List>
    StringHashImpl(const List &s) : h(s.size() + 1) {
        for (auto i = 0U; i < s.size(); i++) {
            for (int k = 0; k < D; k++) {
                h[i + 1][k] = (1LL * h[i][k] * B[k] + s[i] + 1) % P[k];
            }
        }
    }

    StringHashImpl(const char *s) : StringHashImpl(std::string(s)) {}

    // [l, r)
    std::array<int, D> getArray(int l, int r) const {
        static std::vector<std::array<int, D>> spow(1);
        assert(l <= r);

        if (static_cast<int>(spow.size()) < r - l + 1) {
            if (spow[0][0] == 0) {
                spow[0].fill(1);
            }
            int n = spow.size();
            spow.resize(r - l + 1);
            for (int i = n; i < static_cast<int>(spow.size()); i++) {
                for (int k = 0; k < D; k++) {
                    spow[i][k] = 1LL * spow[i - 1][k] * B[k] % P[k];
                }
            }
        }

        std::array<int, D> res = {};
        for (int k = 0; k < D; k++) {
            res[k] = h[r][k] - 1LL * h[l][k] * spow[r - l][k] % P[k];
            res[k] += (res[k] < 0 ? P[k] : 0);
        }
        return res;
    }

    u64 getU64(int l, int r = -1) const {
        if (r == -1) {
            r = (int)h.size() - 1;
        }
        auto arr = getArray(l, r);
        u64 res = arr[0];
        if (D != 1) {
            res ^= u64(arr[1]) << 32;
        }
        return res;
    }
};

namespace compileRand4Str {
    constexpr u64 chaos(u64 x) {
        return x ^ (x << 13) ^ (x >> 3);
    }
    constexpr u64 filter(u64 x, const char* str, std::size_t idx = 0) {
        return str[idx] == '\0' ? x : filter(chaos(x ^ u64(str[idx])), str, idx + 1);
    }
    constexpr u64 rng(u64 seed) {
        return filter(seed ^ __LINE__, __TIME__ __TIMESTAMP__ __FILE__);
    };
    constexpr u64 rngFrom(u64 seed) {
        return rng(seed) % seed + seed;
    };
}

constexpr int HashDimension = 2;
constexpr int HashBase[HashDimension] = {
    static_cast<int>(compileRand4Str::rngFrom(19260817)),
    static_cast<int>(compileRand4Str::rngFrom(20030425))
};
constexpr int HashMod[HashDimension] = {
    static_cast<int>(1E9) + 21,
    static_cast<int>(1E9) + 97
};

using StringHash = StringHashImpl<HashDimension, HashBase, HashMod>;

