#include "Final.hpp"
u64 otherHash(std::string_view text) { return StringHash(text).getU64(0); }
const int* otherHashBases() { return HashBase; }
