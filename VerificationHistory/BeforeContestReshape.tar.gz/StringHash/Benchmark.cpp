#include <bits/stdc++.h>
#include "../BenchmarkSupport.hpp"
namespace Legacy {
#include "Original.hpp"
}
#include "Final.hpp"
using Before=Legacy::StringHashImpl<2,HashBase,HashMod>;
int main(){
    auto bases="-"+std::to_string(HashBase[0])+"-"+std::to_string(HashBase[1]);
    std::mt19937 rng(97);std::string text(500000,'a');for(auto& c:text)c+=rng()%26;
    compare(("string-build"+bases).c_str(),[&]{Before hash(text);return hash.getU64(0);},[&]{StringHash hash(text);return hash.getU64(0);});
    compare(("c-string-build"+bases).c_str(),[&]{Before hash(text.c_str());return hash.getU64(0);},[&]{StringHash hash(text.c_str());return hash.getU64(0);});
    Before old(text);StringHash current(text);std::vector<std::pair<int,int>> queries(500000);for(auto& [l,r]:queries){l=rng()%text.size();r=l+1+rng()%(text.size()-l);}
    compare(("substring-queries"+bases).c_str(),[&]{std::uint64_t sum=0;for(auto [l,r]:queries)sum+=old.getU64(l,r);return sum;},[&]{std::uint64_t sum=0;for(auto [l,r]:queries)sum+=current.getU64(l,r);return sum;});
}
