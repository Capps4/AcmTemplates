# StringHash / GNU++17

C 字符串通过 string_view 读取，避免临时 string；模板序列支持整型符号，字符按 unsigned byte 编码，负整数先正规化再加 1，避免负余数；Clang/libc++ 的 const vector<bool> proxy 明确转换为 bool。getArray(l,r) 完整检查 [l,r)，幂缓存从 1 初始化，修复第一次查询非零起点空区间时旧版返回前缀哈希的问题。

默认随机底数从编译期时间宏改为每进程的稳定共享随机底数。C++17 inline 变量保证不同编译单元引用同一 HashBase/HashMod，单次运行内所有对象可互相比对；不同进程的哈希值不保证一致。若要可复现结果，可自行提供 immutable int 数组作为 StringHashImpl<D,B,P> 参数。每个维度 P>1、0<B<P，参数对象须静态存储且构造之后不可改值。共享幂缓存按该模板实例保存，最大查询长度按需扩展；并发扩展需外部同步。

序列长度<INT_MAX，子串为 [l,r)，0index，空区间各维度为 0。getU64(l,r=-1) 将 1/2 维哈希无损装入 64 位，r=-1 表示到结尾；D>2 必须用 getArray，避免静默丢弃维度。比较子串时还应比较区间长度；哈希相等仍可能碰撞，不能当作字符串相等的数学证明。C 字符串需要非空指针及 NUL 终止；包含 NUL 的数据使用 string/string_view 或字节容器。输入只在构造期间读取，前缀哈希自己持有数据。

构造 O(D*n)，查询在幂缓存足够时 O(D)，扩展累计 O(D*最长查询长度)，空间 O(D*n+共享幂缓存)。类型/别名大驼峰，方法/变量小驼峰，保留 u64 简写。纯 unsigned 的 constexpr mix 实现种子混合，不使用非标准时间宏作为跨编译单元类型参数内容。

测试：独立 unsigned __int128 直接多项式 oracle，逐区间验证；先查空区间、随机任意字节/NUL、负数与 signed/unsigned 极值、vector<bool>、1/2/3 维、临时 string。TestExtra.cpp 单独编译链接，检查默认数组地址和指纹与另一编译单元一致。GCC -O2、Clang ASan/UBSan 均通过，报告包含额外测试源码/hash/编译命令。

自评：保留随机化用途，明确随机化时机的变化；getU64 不吞掉第 3 维。基准旧/新使用相同运行期底数和模数，底数记在场景名/测试输出，输入仍为同一 ASCII 文本。此次建表约 1.23x、C 字符串建表 1.07x、查询 1.07x，完整七轮中位数见 Benchmark.csv。对新修复的空区间/高字节仅运行正确性 oracle。

Final.code-snippets 与 Final.hpp 正文逐字匹配；源码、递归本地 include、测试工具 SHA256 与运行输出在 Results.json。原 VS Code 文件未覆盖。

当前计时方法及数据见 [Performance.md](Performance.md)。本文已有数字属于此前计时记录，原报告保存在 `../VerificationHistory/BeforeTimingFence/`；以 Performance.md 为当前性能依据。
