#pragma once
#include <array>
#include <cassert>
#include <chrono>
#include <limits>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

// SNIPPET BEGIN
using u64 = unsigned long long;
template<int D, const int* B, const int* P>
class StringHashImpl {
    static_assert(D > 0 && B != nullptr && P != nullptr);
    using Hash = std::array<int, D>;
    std::vector<Hash> h;
    inline static std::vector<Hash> powers{[] { Hash one{}; one.fill(1); return one; }()};
    template<class Sequence>
    static auto symbol(const Sequence& sequence, std::size_t i) {
        if constexpr (std::is_integral_v<std::decay_t<decltype(sequence[i])>>) return sequence[i];
        else {
            static_assert(std::is_same_v<typename Sequence::value_type, bool>, "requires integral symbols");
            return bool(sequence[i]); // libc++ may return a proxy even from const vector<bool>.
        }
    }
    static void ensurePowers(std::size_t length) {
        if (powers.size() > length) return;
        auto oldSize = powers.size();
        powers.resize(length + 1);
        for (std::size_t i = oldSize; i <= length; ++i)
            for (int k = 0; k < D; ++k) powers[i][k] = int(1LL * powers[i - 1][k] * B[k] % P[k]);
    }
    template<class I>
    static int encode(I value, int modulus) {
        static_assert(std::is_integral_v<I>);
        if constexpr (std::is_same_v<I, char> || std::is_same_v<I, signed char> || std::is_same_v<I, unsigned char>)
            return int(static_cast<unsigned char>(value)) + 1;
        else if constexpr (std::is_signed_v<I>) {
            auto remainder = value % modulus;
            if (remainder < 0) remainder += modulus;
            return int(remainder) + 1;
        } else {
            auto remainder = value % static_cast<unsigned int>(modulus);
            return int(remainder) + 1;
        }
    }
public:
    template<class Sequence, class = decltype(std::declval<const Sequence&>().size())>
    explicit StringHashImpl(const Sequence& sequence) {
        assert(sequence.size() < std::size_t(std::numeric_limits<int>::max()));
        for (int k = 0; k < D; ++k) assert(P[k] > 1 && 0 < B[k] && B[k] < P[k]);
        h.resize(sequence.size() + 1);
        for (std::size_t i = 0; i < sequence.size(); ++i)
            for (int k = 0; k < D; ++k)
                h[i + 1][k] = int((1LL * h[i][k] * B[k] + encode(symbol(sequence, i), P[k])) % P[k]);
    }
    explicit StringHashImpl(const char* text) : StringHashImpl(std::string_view(text)) {}
    int size() const { return int(h.size() - 1); }
    Hash getArray(int l, int r) const {
        assert(0 <= l && l <= r && r <= size());
        ensurePowers(std::size_t(r - l));
        Hash result{};
        for (int k = 0; k < D; ++k) {
            result[k] = int(h[r][k] - 1LL * h[l][k] * powers[r - l][k] % P[k]);
            if (result[k] < 0) result[k] += P[k];
        }
        return result;
    }
    u64 getU64(int l, int r = -1) const {
        static_assert(D <= 2, "use getArray for more than two dimensions");
        if (r == -1) r = size();
        auto hash = getArray(l, r);
        u64 result = static_cast<unsigned int>(hash[0]);
        if constexpr (D == 2) result |= u64(static_cast<unsigned int>(hash[1])) << 32;
        return result;
    }
};
inline constexpr int HashDimension = 2;
inline constexpr int HashMod[HashDimension] = {1000000021, 1000000097};
namespace strHashDetail {
    constexpr u64 mix(u64 x) {
        x += 0x9e3779b97f4a7c15ULL;
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
        x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
        return x ^ (x >> 31);
    }
    inline const u64 seed = u64(std::chrono::steady_clock::now().time_since_epoch().count());
}
inline const int HashBase[HashDimension] = {
    2 + int(strHashDetail::mix(strHashDetail::seed) % (HashMod[0] - 3)),
    2 + int(strHashDetail::mix(strHashDetail::seed + 1) % (HashMod[1] - 3))
};
using StringHash = StringHashImpl<HashDimension, HashBase, HashMod>;
