#pragma once
#include <cmath>
#include <cerrno>
#include <cstdlib>
#include <iomanip>
#include <istream>
#include <limits>
#include <ostream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>

// SNIPPET BEGIN
template <class T>
class FloatPointNumber {
    static_assert(std::is_floating_point_v<T>);
    static constexpr T EPS = T(1E-12);
    inline static int precision = 6;
    inline static thread_local std::string tokenCache;
    T x{};

    static constexpr int sgn(T value) { return value < -EPS ? -1 : value > EPS; }

public:
    constexpr FloatPointNumber() = default;
    constexpr FloatPointNumber(T value) : x(value) {}
    constexpr T val() const { return x; }
    constexpr operator T() const { return x; }
    constexpr int sgn() const { return sgn(x); }

    template <class G>
    G round() const {
        static_assert(std::is_integral_v<G> && !std::is_same_v<G, bool> && sizeof(G) <= 8);
        T value = std::round(x);
        T high = std::ldexp(T(1), std::numeric_limits<G>::digits);
        T low = std::is_signed_v<G> ? -high : T(0);
        if (!std::isfinite(value) || value < low || value >= high)
            throw std::overflow_error("FloatPointNumber::round: result out of range");
        return G(value);
    }

    static void setprecision(int length) {
        if (length < 0) throw std::invalid_argument("FloatPointNumber: negative precision");
        precision = length;
    }

    constexpr FloatPointNumber& operator+=(FloatPointNumber value) & { x += value.x; return *this; }
    constexpr FloatPointNumber& operator-=(FloatPointNumber value) & { x -= value.x; return *this; }
    constexpr FloatPointNumber& operator*=(FloatPointNumber value) & { x *= value.x; return *this; }
    constexpr FloatPointNumber& operator/=(FloatPointNumber value) & {
        x = T(static_cast<long double>(x) / static_cast<long double>(value.x));
        return *this;
    }
    constexpr FloatPointNumber operator+() const { return *this; }
    constexpr FloatPointNumber operator-() const { return -x; }
    friend constexpr FloatPointNumber operator+(FloatPointNumber a, FloatPointNumber b) { return a += b; }
    friend constexpr FloatPointNumber operator-(FloatPointNumber a, FloatPointNumber b) { return a -= b; }
    friend constexpr FloatPointNumber operator*(FloatPointNumber a, FloatPointNumber b) { return a *= b; }
    friend constexpr FloatPointNumber operator/(FloatPointNumber a, FloatPointNumber b) { return a /= b; }

    friend constexpr bool operator<(FloatPointNumber a, FloatPointNumber b) { return a.x < b.x; }
    friend constexpr bool operator>(FloatPointNumber a, FloatPointNumber b) { return a.x > b.x; }
    friend constexpr bool operator==(FloatPointNumber a, FloatPointNumber b) {
        T delta = a.x - b.x;
        return a.x == b.x || (-EPS <= delta && delta <= EPS);
    }
    friend constexpr bool operator!=(FloatPointNumber a, FloatPointNumber b) { return !(a == b); }
    friend constexpr bool operator<=(FloatPointNumber a, FloatPointNumber b) { return a.x < b.x || a == b; }
    friend constexpr bool operator>=(FloatPointNumber a, FloatPointNumber b) { return a.x > b.x || a == b; }

    // Exact scalar matches keep implicit conversion for std::sqrt/cos/etc unambiguous.
#define FLOAT_POINT_SCALAR_OP(op) \
    template <class U, std::enable_if_t<std::is_arithmetic_v<U>, int> = 0> \
    friend constexpr auto operator op(FloatPointNumber a, U b) { return a op FloatPointNumber(T(b)); } \
    template <class U, std::enable_if_t<std::is_arithmetic_v<U>, int> = 0> \
    friend constexpr auto operator op(U a, FloatPointNumber b) { return FloatPointNumber(T(a)) op b; }
    FLOAT_POINT_SCALAR_OP(+)
    FLOAT_POINT_SCALAR_OP(-)
    FLOAT_POINT_SCALAR_OP(*)
    FLOAT_POINT_SCALAR_OP(/)
    FLOAT_POINT_SCALAR_OP(<)
    FLOAT_POINT_SCALAR_OP(>)
    FLOAT_POINT_SCALAR_OP(<=)
    FLOAT_POINT_SCALAR_OP(>=)
    FLOAT_POINT_SCALAR_OP(==)
    FLOAT_POINT_SCALAR_OP(!=)
#undef FLOAT_POINT_SCALAR_OP

    template <class Input>
    friend Input& operator>>(Input& input, FloatPointNumber& value) {
        // Move the cached capacity into this call: nested reads own separate tokens.
        std::string token = std::move(tokenCache);
        if (!(input >> token)) {
            tokenCache = std::move(token);
            return input;
        }
        char* end = nullptr;
        errno = 0;
        T number;
        if constexpr (std::is_same_v<T, float>) number = std::strtof(token.c_str(), &end);
        else if constexpr (std::is_same_v<T, double>) number = std::strtod(token.c_str(), &end);
        else number = std::strtold(token.c_str(), &end);
        bool invalid = end == token.c_str() || end != token.c_str() + token.size() ||
                       (errno == ERANGE && (number == 0 || !std::isfinite(number)));
        if (invalid) {
            if constexpr (std::is_base_of_v<std::istream, Input>) input.setstate(std::ios_base::failbit);
            else input.setFail();
        } else value.x = number;
        tokenCache = std::move(token);
        return input;
    }

    template <class Output>
    friend Output& operator<<(Output& output, FloatPointNumber value) {
        if constexpr (std::is_base_of_v<std::ostream, Output>)
            output << std::fixed << std::setprecision(precision) << value.x;
        else
            output.writeReal(value.x, precision);
        return output;
    }

    friend constexpr FloatPointNumber abs(FloatPointNumber value) { return value.x < 0 ? -value : value; }
    friend FloatPointNumber sqrt(FloatPointNumber value) { return std::sqrt(value.x); }
    friend FloatPointNumber sin(FloatPointNumber value) { return std::sin(value.x); }
    friend FloatPointNumber cos(FloatPointNumber value) { return std::cos(value.x); }
    friend FloatPointNumber atan2(FloatPointNumber y, FloatPointNumber x) { return std::atan2(y.x, x.x); }
    static const FloatPointNumber PI;
};

template <class T>
inline const FloatPointNumber<T> FloatPointNumber<T>::PI = T(std::acos(-1.L));

using Float = FloatPointNumber<double>;
