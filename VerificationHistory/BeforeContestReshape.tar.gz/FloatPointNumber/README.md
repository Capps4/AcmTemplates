# FloatPointNumber

保留 FloatPointNumber<T>/Float、val/sgn、setprecision 和 PI，T 为原生浮点类型。用 C++17 inline 保存精度/常量；算术和比较可 constexpr 求值。删除不合法的 std 命名空间函数注入，改为隐式原生 T 转换以兼容原 Geo2/Geo3 的 std::sqrt/cos/atan2 等调用；这些 std 函数返回原生浮点。ADL 的 abs/sqrt/sin/cos/atan2 返回包装类型。混合算术标量的隐藏友元避免隐式转换导致二义性，不支持不同底层类型包装类的混合操作。

round<G> 修复负数，以 std::round 四舍五入（半整数远离零），取消旧版正方向 EPS 偏移；非有限值/超出 G 可表示范围会抛 overflow_error，G 为非 bool、至多 64 位整数。除法保留 long double 中间精度。比较保留原来用途：<、> 为原生严格比较，==/<=/>= 使用绝对 EPS=1e-12；近似相等不传递，不适合作为哈希键相等关系。sgn 用于有限几何量；NaN 比较按原生行为处理，sgn(NaN) 仍是 0。NaN 不应作为排序输入。

读取局部 token 后按 T 用 strtof/strtod/strtold，失败保留原值，不从陈旧 token 解析。C++17 inline thread_local 缓存字符串容量，每次移动至局部、退出归还，减少长 token 反复分配；重入时外层仍拥有独立 token，线程之间独立。异常会丢弃本次缓存容量，不影响值/其他读取；最大缓存容量在线程结束时释放。token 必须完整，无法表示的溢出/下溢置 fail，非零 subnormal 接受；依赖 C locale，竞赛默认环境与原 stod 相同。直接委托 iostream 浮点提取曾出现约十倍回退，故采用 token 路径。输出默认 fixed 6 位，setprecision 调整该 T 的共享精度并拒绝负数（不要并发修改输出精度）；标准流按原接口改变格式状态，ostringstream 也可直接使用。非标准输出后端提供 writeReal(value,precision)，输入后端需 string operator>>、bool 和 setFail()，由 FastInputOutput 实现。没有索引/区间 API；类型大驼峰，已有 setprecision 名字作为兼容接口保留。

测试 constexpr、混合标量/标准数学/ADL数学、十万原生算术对照、正负取整/极值/NaN、失败读取、嵌套/四线程读取、输出格式和实际双翻译单元共享精度。Point 的独立测试编译未修改 Geo2/Geo3，并运行凸包/圆/直线/三维平面及多面体，作为联合兼容证据。

BenchmarkBaseline.hpp 从 Original.hpp 只去除不能合法编译的、算术基准未使用的 std 数学 overload 定义；其他旧算术、读取、输出保留。旧输出绑定到 ostream&，规避旧实现不支持 ostringstream& 返回的问题，新版使用同一绑定。相同数据/校验和的算术、解析、格式化七轮中位数见 Performance.md；不把语法变化宣称为提速。
