#pragma once
#include <cassert>
#include <cstddef>
#include <limits>
#include <utility>
#include <vector>

// SNIPPET BEGIN
class TopSort {
    static constexpr int endPoint(int vertex) { return vertex; }
    template<class Weight>
    static constexpr int endPoint(const std::pair<int, Weight>& edge) { return edge.first; }
public:
    template<class Row>
    std::vector<int> operator()(const std::vector<Row>& adj) const {
        assert(adj.size() <= std::size_t(std::numeric_limits<int>::max()));
        int n = int(adj.size());
        std::vector<std::size_t> degree(n);
        for (const auto& row : adj) for (const auto& edge : row) {
            int vertex = endPoint(edge);
            assert(0 <= vertex && vertex < n);
            ++degree[vertex];
        }
        std::vector<int> result;
        result.reserve(n);
        for (int vertex = 0; vertex < n; ++vertex) if (!degree[vertex]) result.push_back(vertex);
        for (std::size_t head = 0; head < result.size(); ++head) {
            int vertex = result[head];
            for (const auto& edge : adj[vertex]) {
                int next = endPoint(edge);
                if (--degree[next] == 0) result.push_back(next);
            }
        }
        return result; // result.size() == adj.size() iff the graph is acyclic.
    }
};
inline constexpr TopSort topSort{};
