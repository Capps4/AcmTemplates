#include "Final.hpp"
#include "../TestSupport.hpp"
#include <sstream>
static_assert(Point(1, 2).cross(Point(3, 4)) == -2);
static_assert((Point(1, 2) + Point(3, 4)).x == 4);
static_assert(Point(3, 4).dist2(Point(0, 0)) == 25);
int main() {
    for (int iteration = 0; iteration < 100000; ++iteration) {
        Point a(randomInt(-1000000, 1000000), randomInt(-1000000, 1000000));
        Point b(randomInt(-1000000, 1000000), randomInt(-1000000, 1000000));
        Point c(randomInt(-1000000, 1000000), randomInt(-1000000, 1000000));
        CHECK(a.dot(b) == 1LL * a.x * b.x + 1LL * a.y * b.y);
        CHECK(a.cross(b) == 1LL * a.x * b.y - 1LL * a.y * b.x);
        __int128 ax = __int128(b.x) - a.x, ay = __int128(b.y) - a.y;
        __int128 bx = __int128(c.x) - a.x, by = __int128(c.y) - a.y;
        CHECK(a.cross(b, c) == ax * by - ay * bx);
        CHECK(a.dist2(b) == ax * ax + ay * ay);
        CHECK(a.to(b) + a == b);
        CHECK(a.rot90().dot(a) == 0 && a.rot90().len2() == a.len2());
        CHECK(std::abs(a.dist(b).val() - std::hypot(double(ax), double(ay))) < 1E-8);
    }
    Point low(std::numeric_limits<int>::min(), 0), one(1, 0);
    long long difference = 1LL - low.x;
    CHECK(low.dist2(one) == difference * difference);
    CHECK(low.cross(one, Point(1, 1)) == difference);
    using BigPoint = PointImpl<long long, __int128, Float>;
    BigPoint a(-4000000000LL, 0), b(4000000000LL, 1);
    CHECK(a.dist2(b) == __int128(8000000000LL) * 8000000000LL + 1);
    using RealPoint = PointImpl<Float, Float, Float>;
    RealPoint p(3, 4);
    CHECK(p.len().val() == 5);
    auto turned = p.rot(Float::PI / 2);
    CHECK(std::abs(turned.x.val() + 4) < 1E-12 && std::abs(turned.y.val() - 3) < 1E-12);
    CHECK(std::abs(p.angle(p.rot90()).val() - Float::PI.val() / 2) < 1E-12);
    CHECK(Point::O == Point(0, 0));
    CHECK(Point(1, -1).half() == 1 && Point(-1, 0).half() == 1 && Point(1, 0).half() == 0);
    std::istringstream input("3 4");
    Point parsed; input >> parsed;
    std::ostringstream output; output << parsed;
    CHECK(parsed == Point(3, 4) && output.str() == "(3, 4)");
    std::cout << "Point constexpr, 100K independent wide algebra/distance oracle, wide-before-subtract, rotation/angle/IO PASS\n";
}
