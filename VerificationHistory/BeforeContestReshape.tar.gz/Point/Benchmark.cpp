#include <bits/stdc++.h>
#include "../FloatPointNumber/Final.hpp"
namespace Legacy {
#include "Original.hpp"
}
#include "Final.hpp"
#include "../BenchmarkSupport.hpp"
template <class P>
std::uint64_t algebra(const std::vector<P>& points) {
    std::uint64_t result = 0;
    for (std::size_t i = 1; i + 1 < points.size(); ++i)
        result += std::uint64_t(points[i].cross(points[i - 1], points[i + 1])) + std::uint64_t(points[i].dist2(points[i - 1]));
    return result;
}
template <class P>
std::uint64_t distance(const std::vector<P>& points) {
    double sum = 0;
    for (std::size_t i = 1; i < points.size(); ++i) sum += points[i].dist(points[i - 1]).val();
    return std::uint64_t(sum * 1000);
}
int main() {
    std::mt19937 rng(20261001);
    std::vector<Point> points;
    std::vector<Legacy::Point> old;
    for (int i = 0; i < 1000000; ++i) {
        int x = int(rng() % 2000001) - 1000000, y = int(rng() % 2000001) - 1000000;
        points.emplace_back(x, y); old.emplace_back(x, y);
    }
    compare("wide-algebra-1M", [&] { return algebra(old); }, [&] { return algebra(points); });
    compare("distance-1M", [&] { return distance(old); }, [&] { return distance(points); });
}
