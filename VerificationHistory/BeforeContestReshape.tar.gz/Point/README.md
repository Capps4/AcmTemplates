# Point

保留 PointImpl<T,G,F>、Point/Vec 与 Value/Wide/Real/Wide3/O。依赖 FloatPointNumber（snippet 要先插入依赖）。使用 C++17 conditional_t/is_integral_v，标量代数和比较支持 constexpr；保持二维点简单布局。静态 O inline，不引入额外动态内存或成员。

dist2 和三个点的 cross 改为先转 Wide 再减坐标，避免原版在 T 中构造向量时已溢出。dot/二点 cross 仍在 Wide 中乘加，len/dist 使用 Real。调用方保证所有最终乘加能在 Wide 中表示；这不是任意范围精确整数几何。默认 Point=int、Wide=long long，极端全 int 范围距离平方仍可能不适合 long long；可显式选 PointImpl<long long,__int128,Float> 并保证 128 位结果范围。普通点的加减、to、取负、缩放仍返回 T，调用方保证 T 不溢出。

rot 为浮点坐标用途；angle 的两个向量非零，返回有向 atan2 角，dist 为欧氏距离。流运算先执行再返回具体 Input/Output，修复直接 istringstream/ostringstream 无法编译的返回类型。类型大驼峰、函数/变量小驼峰；没有区间 API，坐标 x/y 保留。

十万组随机点用独立 __int128 代数和 hypot 检查叉积/距离/转向；测试 constexpr、宽化前减法溢出反例、128 位自定义 Point、旋转/角度/流。TestCaseGeometry.cpp 使用 GeometryCompatibility 内逐字展开的未修改 Geo2/Geo3 快照，检查凸包、点定位、交点、圆切点、三维混合积、平面交点及四面体面积/体积。这些是接入测试，未升级几何算法本身，源文件未参与写操作。

Benchmark 对比旧 Point 与最终 Point，两者使用相同最终 Float 依赖，单独量化 Point 变化。旧版有效坐标范围内相同输入、结果校验、七轮中位数；本机批量叉积/距离平方出现明显回退，宽化为 64 位运算削弱了 32 位运算的优化机会。距离开方基本持平。保留简洁的宽化修复；已知坐标差适合 T 时，可显式用 to(p).len2()/to(a).cross(to(b)) 走原来的窄向量计算路径。当前性能见 Performance.md，原始记录见 Results.json。
