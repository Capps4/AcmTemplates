#include "Final.hpp"
#include <algorithm>
#include <deque>
#include <memory>
#include <string>
#include <utility>
#include <vector>
#include "../GeometryCompatibility/Geo2.hpp"
#include "../GeometryCompatibility/Geo3.hpp"
#include "../TestSupport.hpp"
int main() {
    std::vector<Point> points{{0, 0}, {4, 0}, {4, 3}, {0, 3}, {1, 1}};
    auto hull = points.hull();
    CHECK(hull.size() == 4 && hull.loc(Point(1, 1)) == "IN");
    CHECK(hull.loc(Point(4, 1)) == "ON" && hull.loc(Point(5, 1)) == "OUT");
    CHECK(hull.polygon().area().val() == 12 && hull.polygon().perimeter().val() == 14);
    CHECK(hull[hull.support(Point(1, 0))].x == 4);
    auto intersection = Line(Point(0, 0), Point(2, 2)).relation(Line(Point(0, 2), Point(2, 0)));
    CHECK(intersection.type == "ONE" && intersection.ps[0].x == 1 && intersection.ps[0].y == 1);
    auto two = Circle(Point(0, 0), 2).relation(Line(Point(-3, 0), Point(3, 0)));
    CHECK(two.type == "TWO" && two.ps[0].x == -2 && two.ps[1].x == 2);
    using RealPoint = PointImpl<Float, Float, Float>;
    auto q = LineImpl<RealPoint>({0, 0}, {4, 0}).foot({2, 3});
    CHECK(q == RealPoint(2, 0));
    CircleImpl<RealPoint> circum({0, 0}, {2, 0}, {0, 2});
    CHECK(circum.o == RealPoint(1, 1) && std::abs(circum.r.val() - std::sqrt(2.)) < 1E-12);
    auto tangents = CircleImpl<RealPoint>({0, 0}, 1).tangents(RealPoint(2, 0));
    CHECK(tangents.size() == 2);
    for (auto p : tangents) CHECK(std::abs(p.len2().val() - 1) < 1E-12);
    Point3 x(1, 0, 0), y(0, 1, 0), z(0, 0, 1);
    CHECK(x.cross(y) == z && x.triple(y, z) == 1);
    CHECK(Plane3(Point3(0, 0, 0), x, y).side(z) == 1);
    auto hit = Plane3(Point3(0, 0, 0), x, y).relation(Line3(Point3(1, 1, -1), Point3(1, 1, 1)));
    CHECK(hit.type == "ONE" && hit.ps[0].z == 0 && hit.ps[0].x == 1);
    CHECK(std::abs(Line3(Point3(0, 0, 0), x).dist(Point3(0, 3, 4)).val() - 5) < 1E-12);
    Polyhedron3 tetra;
    tetra.ps = {Point3(0, 0, 0), x, y, z};
    tetra.fs = {Face3(1, 2, 3), Face3(0, 2, 1), Face3(0, 1, 3), Face3(0, 3, 2)};
    CHECK(tetra.vol6() == 1 && std::abs(tetra.vol().val() - 1. / 6) < 1E-12);
    CHECK(std::abs(tetra.area().val() - (1.5 + std::sqrt(3.) / 2)) < 1E-12);
    std::cout << "Unchanged Geo2/Geo3 snapshots + final Float/Point: hull, circle/line/tangents, 3D plane/polyhedron compatibility PASS\n";
}
