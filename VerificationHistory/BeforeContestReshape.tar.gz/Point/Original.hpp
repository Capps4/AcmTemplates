#pragma once
#include <bits/stdc++.h>
using i64 = long long;
template <class T, class G, class F>
struct PointImpl {
    typedef T Value;
    typedef G Wide;
    typedef F Real;
    typedef typename std::conditional<
        std::is_integral<T>::value, __int128, G>::type Wide3;

    T x, y;
    constexpr PointImpl() : x(), y() {}
    constexpr PointImpl(T x, T y) : x(x), y(y) {}

    PointImpl operator+() const {
        return *this;
    }

    PointImpl operator-() const {
        return PointImpl(-x, -y);
    }

    PointImpl &operator+=(PointImpl p) {
        x += p.x;
        y += p.y;
        return *this;
    }

    PointImpl &operator-=(PointImpl p) {
        x -= p.x;
        y -= p.y;
        return *this;
    }

    PointImpl &operator*=(T k) {
        x *= k;
        y *= k;
        return *this;
    }

    friend PointImpl operator+(PointImpl a, PointImpl b) {
        return a += b;
    }

    friend PointImpl operator-(PointImpl a, PointImpl b) {
        return a -= b;
    }

    friend PointImpl operator*(PointImpl p, T k) {
        return p *= k;
    }

    friend PointImpl operator*(T k, PointImpl p) {
        return p *= k;
    }

    // 返回从当前点指向目标点的向量。
    PointImpl to(PointImpl p) const {
        return p - *this;
    }

    Wide dot(PointImpl p) const {
        return Wide(x) * p.x + Wide(y) * p.y;
    }

    Wide cross(PointImpl p) const {
        return Wide(x) * p.y - Wide(y) * p.x;
    }

    Wide cross(PointImpl a, PointImpl b) const {
        return to(a).cross(to(b));
    }

    Wide len2() const {
        return dot(*this);
    }

    Real len() const {
        Real v(len2());
        return std::sqrt(v);
    }

    Wide dist2(PointImpl p) const {
        return to(p).len2();
    }

    Real dist(PointImpl p) const {
        Real v(dist2(p));
        return std::sqrt(v);
    }

    PointImpl rot90() const {
        return PointImpl(-y, x);
    }

    PointImpl rot(Real ang) const {
        static_assert(!std::is_integral<T>::value,
                      "Point::rot needs floating Point");
        Real c = std::cos(ang), s = std::sin(ang);
        return PointImpl(T(x * c - y * s), T(x * s + y * c));
    }

    // 返回两个非零向量的有向夹角。
    Real angle(PointImpl p) const {
        assert(*this != O and p != O);
        Real cr(cross(p)), dt(dot(p));
        return std::atan2(cr, dt);
    }

    // 返回向量所在的极角半平面。
    int half() const {
        if (y < 0) return 1;
        if (y > 0) return 0;
        return x < 0;
    }

    bool operator==(PointImpl p) const {
        return x == p.x and y == p.y;
    }

    bool operator!=(PointImpl p) const {
        return !(*this == p);
    }

    bool operator<(PointImpl p) const {
        if (x < p.x) return true;
        if (p.x < x) return false;
        return y < p.y;
    }

    template <class Input>
    friend Input &operator>>(Input &in, PointImpl &p) {
        return in >> p.x >> p.y;
    }

    template <class Output>
    friend Output &operator<<(Output &out, PointImpl p) {
        return out << '(' << p.x << ", " << p.y << ')';
    }

    static const PointImpl O;
};

template <class T, class G, class F>
const PointImpl<T, G, F> PointImpl<T, G, F>::O = PointImpl<T, G, F>();

using Point = PointImpl<int, long long, Float>;
using Vec = Point;

