#pragma once
#include <algorithm>
#include <cassert>
#include <vector>
// SNIPPET BEGIN
struct IdentityKey {
    template<class T>
    constexpr int operator()(const T& x) const { return x; }
};

// Stable index order; keys are in [0, maxKey]. O(n + maxKey).
template<class T, class Key = IdentityKey>
std::vector<int> countingSortOrder(const std::vector<T>& a, Key key = {}) {
    if (a.empty()) return {};
    int maxKey = 0;
    for (const auto& x : a) {
        int k = key(x);
        assert(k >= 0);
        maxKey = std::max(maxKey, k);
    }
    std::vector<int> count(std::size_t(maxKey) + 1), order(a.size());
    for (const auto& x : a) ++count[key(x)];
    for (std::size_t i = 1; i < count.size(); ++i) count[i] += count[i - 1];
    for (int i = int(a.size()); i-- > 0;) order[--count[key(a[i])]] = i;
    return order;
}
