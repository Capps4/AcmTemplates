#pragma once
#include <bits/stdc++.h>
using i64 = long long;
// 按 a 的值返回下标排序
template <class T, class Key = int (*)(T)>
std::vector<int> countingSortOrder(const std::vector<T> &a, Key key = [](T x) -> int { return x; }) {
    auto it = std::max_element(a.begin(), a.end(), [&](T p, T q) {
        return key(p) < key(q);
    });
    const int maxV = key(*it);
    std::vector<int> cnt(maxV + 1);

    for (auto i = 0U; i < a.size(); i++) {
        cnt[key(a[i])] += 1;
    }
    for (int i = 1; i <= maxV; i++) {
        cnt[i] += cnt[i - 1];
    }
    std::vector<int> res(a.size());
    for (int i = static_cast<int>(a.size()) - 1; i >= 0; i--) {
        res[--cnt[key(a[i])]] = i;
    }

    return res;
}

