#pragma once
#include <bits/stdc++.h>
using i64 = long long;
template <class T>
std::string gauss(std::vector<std::vector<T>> &a) { // 传入增广矩阵
    const int n = a.size();
    const int m = a[0].size();
    assert(m > n);

    int c = 0, r = 0;
    for (; c < n; c++) { // c列r行，遍历列
        int tmp = r;
        for (int i = r; i < n; i++) { // 寻找列主元
            if (a[i][c] != 0) {
                tmp = i;
            }
        }
        if (a[tmp][c] == 0) { // 当前列全为0
            continue;
        }

        std::swap(a[tmp], a[r]); // 交换列主元

        for (int i = m - 1; i >= c; i--) { // 倒序处理
            a[r][i] /= a[r][c];
        }

        for (int i = r + 1; i < n; i++) {
            if (a[i][c] != 0) {
                for (int j = m - 1; j >= c; j--) {
                    a[i][j] -= a[r][j] * a[i][c];
                }
            }
        }

        r += 1;
    }

    if (r < n) {
        for (int i = r; i < n; i++) {
            if (a[i][n] != 0) {
                return "NoSolution";
            }
        }
        return "InfSolution";
    }

    for (int i = n - 1; i > 0; i--) {
        for (int j = i - 1; j >= 0; j--) {
            const T b = a[j][i];
            for (int k = n; k < m; k++) {
                a[j][k] -= b * a[i][k];
            }
            a[j][i] = 0;
        }
    }

    // 解会放在 a[i][n]  (0 <= i < n)
    return "OK";
}

template <class T>
struct MatrixUtil {
    std::string status;
    std::vector<std::vector<T>> inv;

    MatrixUtil(const std::vector<std::vector<T>> &a): status{}, inv{} {
        const int n = a.size();
        assert(static_cast<int>(a[0].size()) == n);

        std::vector<std::vector<T>> b(n, std::vector<T>(n * 2));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                b[i][j] = a[i][j];
            }
            b[i][i + n] = 1;
        }

        status = gauss(b);
        if (status == "OK") {
            inv = std::vector<std::vector<T>>(n, std::vector<T>(n));
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    inv[i][j] = b[i][j + n];
                }
            }
        }
    }
};

