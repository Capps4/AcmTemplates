#pragma once
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstddef>
#include <limits>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

// SNIPPET BEGIN
namespace gaussDetail {
    template<class T, class = void> struct HasInverse : std::false_type {};
    template<class T> struct HasInverse<T, std::void_t<decltype(std::declval<const T&>().inv())>>
        : std::is_convertible<decltype(std::declval<const T&>().inv()), T> {};
}
template<class T>
std::string gauss(std::vector<std::vector<T>>& matrix) {
    static_assert(!std::is_integral_v<T>, "Gaussian elimination needs a field or floating-point type");
    if (matrix.empty()) return "OK";
    assert(matrix.size() <= std::size_t(std::numeric_limits<int>::max()));
    assert(matrix[0].size() <= std::size_t(std::numeric_limits<int>::max()));
    int n = int(matrix.size()), m = int(matrix[0].size());
    assert(m > n);
    for (const auto& row : matrix) assert(row.size() == std::size_t(m));
    int rank = 0;
    for (int column = 0; column < n && rank < n; ++column) {
        int pivot = -1;
        for (int row = rank; row < n; ++row) if (matrix[row][column] != T{}) {
            if constexpr (std::is_floating_point_v<T>) {
                if (pivot == -1 || std::abs(matrix[row][column]) > std::abs(matrix[pivot][column])) pivot = row;
            } else pivot = row;
        }
        if (pivot == -1) continue;
        std::swap(matrix[pivot], matrix[rank]);
        auto& chosen = matrix[rank];
        T scale = chosen[column];
        chosen[column] = T(1);
        if constexpr (gaussDetail::HasInverse<T>::value) {
            T inverse = scale.inv();
            for (int j = column + 1; j < m; ++j) chosen[j] *= inverse;
        } else {
            for (int j = column + 1; j < m; ++j) chosen[j] /= scale;
        }
        for (int row = rank + 1; row < n; ++row) {
            auto& current = matrix[row];
            T factor = current[column];
            if (factor == T{}) continue;
            current[column] = T{};
            for (int j = column + 1; j < m; ++j) current[j] -= chosen[j] * factor;
        }
        ++rank;
    }
    if (rank < n) {
        for (int row = rank; row < n; ++row) for (int column = n; column < m; ++column)
            if (matrix[row][column] != T{}) return "NoSolution";
        return "InfSolution";
    }
    for (int row = n - 1; row > 0; --row) for (int previous = 0; previous < row; ++previous) {
        T factor = matrix[previous][row];
        if (factor == T{}) continue;
        for (int column = n; column < m; ++column) matrix[previous][column] -= factor * matrix[row][column];
        matrix[previous][row] = T{};
    }
    return "OK";
}

template<class T>
struct MatrixUtil {
    std::string status;
    std::vector<std::vector<T>> inv;
    explicit MatrixUtil(const std::vector<std::vector<T>>& matrix) {
        assert(matrix.size() <= std::size_t(std::numeric_limits<int>::max() / 2));
        int n = int(matrix.size());
        for (const auto& row : matrix) assert(row.size() == std::size_t(n));
        std::vector<std::vector<T>> augmented(n, std::vector<T>(2 * std::size_t(n)));
        for (int row = 0; row < n; ++row) {
            std::copy(matrix[row].begin(), matrix[row].end(), augmented[row].begin());
            augmented[row][n + row] = T(1);
        }
        status = ::gauss(augmented);
        if (status == "OK") {
            inv.reserve(n);
            for (const auto& row : augmented) inv.emplace_back(row.begin() + n, row.end());
        }
    }
};
