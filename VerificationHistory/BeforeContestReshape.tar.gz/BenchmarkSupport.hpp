#pragma once
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>

inline volatile std::uint64_t benchmarkSink = 0;
inline bool benchmarkReverse = false;
// GCC/Clang compiler barriers: do not lift memory work out of the timed region.
inline void benchmarkClobber() { asm volatile("" ::: "memory"); }
inline void benchmarkConsume(std::uint64_t value) { asm volatile("" : : "r"(value) : "memory"); }
struct BenchmarkTiming {
    double median;
    std::array<double, 7> samples;
};
template<class F>
BenchmarkTiming measure(F&& run) {
    benchmarkSink ^= run();
    BenchmarkTiming timing{};
    for (auto& sample : timing.samples) {
        benchmarkClobber();
        auto start = std::chrono::steady_clock::now();
        benchmarkClobber();
        auto result = run();
        benchmarkConsume(std::uint64_t(result));
        auto stop = std::chrono::steady_clock::now();
        benchmarkSink ^= result;
        sample = std::chrono::duration<double, std::milli>(stop - start).count();
    }
    auto sorted = timing.samples;
    std::sort(sorted.begin(), sorted.end());
    timing.median = sorted[sorted.size() / 2];
    return timing;
}
inline void printSamples(const std::array<double, 7>& samples) {
    std::cerr << '[';
    for (std::size_t i = 0; i < samples.size(); ++i) {
        if (i) std::cerr << ',';
        std::cerr << samples[i];
    }
    std::cerr << ']';
}
template<class Before, class After>
void compare(const char* name, Before&& before, After&& after) {
    auto oldResult = before(), newResult = after();
    if (oldResult != newResult) {
        std::cerr << "Benchmark checksum mismatch: " << name << '\n';
        std::exit(1);
    }
    BenchmarkTiming original, final;
    if (benchmarkReverse) { final = measure(after); original = measure(before); }
    else { original = measure(before); final = measure(after); }
    std::cout << name << ',' << original.median << ',' << final.median << ',';
    if (original.median > 0 && final.median > 0) std::cout << original.median / final.median;
    else std::cout << "NA";
    std::cout << ',' << newResult << '\n';
    std::cerr << std::setprecision(17) << "BENCHMARK_SAMPLES:{\"scenario\":" << std::quoted(name)
              << ",\"original\":";
    printSamples(original.samples);
    std::cerr << ",\"final\":";
    printSamples(final.samples);
    std::cerr << ",\"checksum\":" << std::uint64_t(newResult)
              << ",\"first\":\"" << (benchmarkReverse ? "final" : "original") << "\"}\n";
    benchmarkReverse = !benchmarkReverse;
}
