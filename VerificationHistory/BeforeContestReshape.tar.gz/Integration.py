"""Compile the exported snippet bodies together, following production dependencies."""
import hashlib
import json
import re
from pathlib import Path
from Run import CXX, SAN_CXX, run, execute
from Export import ROOT, CURSOR, expand

DIRECTORY = ROOT / 'Integration'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inputs():
    manifest = json.loads((ROOT / 'Manifest.json').read_text())
    return {item['module']: item for item in manifest if item['status'] == 'verified'}

def assemble(modules, with_test=True):
    visited, order = set(), []
    def visit(name):
        if name in visited:
            return
        visited.add(name)
        for dependency in modules[name]['dependencies']:
            visit(dependency)
        order.append(name)
    for name in sorted(modules):
        if modules[name].get('role') != 'entrypoint':
            visit(name)
    headers = set()
    bodies = []
    for name in order:
        headers.update(re.findall(r'^#include <([^>]+)>', (ROOT / name / 'Final.hpp').read_text(), re.MULTILINE))
        body = next(iter(json.loads((ROOT / name / 'Final.code-snippets').read_text()).values()))['body']
        expanded = expand(body)
        bodies.append('// Module: ' + name + '\n' + expanded)
    return ('\n'.join('#include <' + header + '>' for header in sorted(headers)) + '\n\n' +
            '\n\n'.join(bodies) + ('\n#include "Test.hpp"\n' if with_test else '\n'))

def entry_source(name, modules):
    body = next(iter(json.loads((ROOT / name / 'Final.code-snippets').read_text()).values()))['body']
    source = expand(body, internal_cursor=True, restore_cursor=True)
    if name == 'init_':
        code = "long long value; while (std::cin >> value) std::cout << value * 2 << '\\n';"
    else:
        code = "long long value; if (std::cin >> value) std::cout << value * 2 << '\\n';"
    source = source.replace(CURSOR, code)
    index = re.search(r'^(?:void solve|int main)\(', source, re.MULTILINE).start()
    # Entry headers come first, just as in a contest submission. This also tests
    # all library bodies under the actual GNU bits/stdc++.h debugger macros.
    return source[:index] + assemble(modules, with_test=False) + source[index:]

def entry_cases(name):
    if name == 'init_':
        return [('', ''), ('4 -7 0\n', '8\n-14\n0\n'), ('bad\n', '')]
    return [('', ''), ('bad\n', ''), ('-1\n', ''), ('-2147483648\n', ''),
            ('0\n', ''), ('3\n4 -7 0\n', '8\n-14\n0\n'), ('2\n5\n', '10\n')]

def fingerprint(modules):
    paths = ['Integration.py', 'Integration/Test.hpp', 'TestSupport.hpp']
    for name in modules:
        paths.extend([name + '/Final.hpp', name + '/Final.code-snippets'])
    def collect(path):
        for relative in re.findall(r'^\s*#include\s+"([^"]+)"', path.read_text(), re.MULTILINE):
            included = (path.parent / relative).resolve()
            name = str(included.relative_to(ROOT))
            if name not in paths:
                paths.append(name)
                collect(included)
    collect(ROOT / 'Integration/Test.hpp')
    return {name: digest(ROOT / name) for name in paths}

def verify():
    modules = inputs()
    source = assemble(modules)
    tracked = fingerprint(modules)
    source_path = DIRECTORY / 'Build' / 'Finals.cpp'
    source_path.parent.mkdir(exist_ok=True)
    # Source is included from Build, but Test.hpp is one directory above.
    source_path.write_text(source.replace('#include "Test.hpp"', '#include "../Test.hpp"'))
    records = []
    entries = {name: {'module': name, 'tests': []} for name in modules if modules[name].get('role') == 'entrypoint'}
    for name, entry in entries.items():
        path = source_path.parent / (name + '.cpp')
        path.write_text(entry_source(name, modules))
        entry['sourceSha256'] = digest(path)
    for compiler, flags, label in [
        (CXX, ['-O2', '-Wall', '-Wextra'], 'optimized'),
        (SAN_CXX, ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer'], 'sanitized')
    ]:
        executable = source_path.parent / label
        command = [compiler, '-std=gnu++17', *flags, str(source_path), '-o', str(executable)]
        run(command)
        records.append({'command': command, 'output': run([str(executable)]).strip()})
        for name, entry in entries.items():
            path = source_path.parent / (name + '.cpp')
            executable = source_path.parent / (label + '-' + name)
            command = [compiler, '-std=gnu++17', *flags, str(path), '-o', str(executable)]
            run(command)
            cases = []
            for text, expected in entry_cases(name):
                result = execute([str(executable)], input_text=text)
                assert result.stdout == expected, f'{name}: wrong entry behavior for {text!r}'
                cases.append({'input': text, 'expected': expected, 'output': result.stdout})
            entry['tests'].append({'command': command, 'cases': cases})
    assert fingerprint(modules) == tracked, 'Integration input changed during verification'
    report = {'modules': sorted(modules), 'sha256': tracked, 'sourceSha256': digest(source_path),
              'tests': records, 'entrypoints': list(entries.values())}
    (DIRECTORY / 'Results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(f"{len(modules)} exported snippets: GCC + ASan/UBSan library and {len(entries)} actual-entry integration PASS")

def audit():
    modules = inputs()
    report = json.loads((DIRECTORY / 'Results.json').read_text())
    assert report['modules'] == sorted(modules), 'Integration module set is stale'
    assert report['sha256'] == fingerprint(modules), 'Integration inputs are stale'
    source_path = DIRECTORY / 'Build' / 'Finals.cpp'
    assert source_path.read_text() == assemble(modules).replace('#include "Test.hpp"', '#include "../Test.hpp"')
    assert digest(source_path) == report['sourceSha256']
    assert len(report['tests']) == 2 and all(item['output'] for item in report['tests'])
    entries = {item['module']: item for item in report.get('entrypoints', [])}
    assert set(entries) == {name for name in modules if modules[name].get('role') == 'entrypoint'}
    for name, entry in entries.items():
        path = DIRECTORY / 'Build' / (name + '.cpp')
        assert path.read_text() == entry_source(name, modules) and digest(path) == entry['sourceSha256']
        assert len(entry['tests']) == 2
        for record in entry['tests']:
            assert str(path) in record['command']
            assert [(case['input'], case['expected']) for case in record['cases']] == entry_cases(name)
            assert all(case['output'] == case['expected'] for case in record['cases'])

if __name__ == '__main__':
    verify()
