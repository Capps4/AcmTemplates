# Comb / GNU++17

保留 jc、ijc、A、C 接口，提供公开构造函数用于独立缓存。`inline auto& comb` 引用共享实例，避免原来 `auto` 的整表复制；shared(m) 会满足后来请求的容量。modulus 变化时重建缓存，支持新 ModuloInteger 的 int/long long 模数。增长上界与乘 2 使用 long long，消除旧版 x*2 溢出和 std::min(int,long long) 无法编译的问题。

依赖 ModuloInteger snippet（先插入）；Final.hpp 自动包含对应最终头文件。类型名 Comb 大驼峰，保留既有 A/C 数学接口与 lowerCamelCase 方法。factorial 的下标从 0 开始，0! = 1；组合数的数学参数不是区间。

契约：模数为大于 1 的质数，jc/ijc 及有效 A/C 的 a 必须满足 0 <= a < mod，并能用 int 表示。init(m) 将缓存上界截为 mod-1，直接查询越界指数由 assert 检查；关闭断言后调用者仍需满足契约。无 Lucas 扩展。非法 k（负数或大于 a）的 A/C 返回 0。动态模数仍为共享状态，改模数后旧 ModuloInteger 对象无效；本类下次使用时仅重建自己的缓存。

测试：Pascal 加法递推作为独立组合数 oracle；逐项乘法验证排列数与阶乘，检查逆阶乘；覆盖 97 的完整有效范围、常用固定模数、61 位质数、反复切换动态模数与重复初始化。GCC -O2 与 Clang ASan/UBSan 均通过。

性能：300000 阶建表与 500000 次查询，旧/新校验和相同，七轮中位数见 Benchmark.csv。此次建表约 1.00x、查询约 0.96x，视为基本持平；收益主要是独立实例、模数兼容与取消 singleton 拷贝。建表 O(n)，查询 O(1)，缓存 O(n)。

自评：没有加入不必要的通用组合数算法。保持原查询行为；init 边界和动态模数失效规则写明，保留断言。最终 snippet 与头文件正文逐字匹配，Results.json 记录依赖和测试输入文件 SHA256。原 VS Code 文件未覆盖。

当前计时方法及数据见 [Performance.md](Performance.md)。本文已有数字属于此前计时记录，原报告保存在 `../VerificationHistory/BeforeTimingFence/`；以 Performance.md 为当前性能依据。
