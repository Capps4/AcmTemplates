#pragma once
#include <algorithm>
#include <cassert>
#include <cstddef>
#include <limits>
#include <vector>

// SNIPPET BEGIN
class Scc {
public:
    std::vector<int> dfn, low, bel;
    std::vector<std::vector<int>> g;
    int cntBlock = 0;
    explicit Scc(const std::vector<std::vector<int>>& adj, bool buildCondensation = true)
        : dfn(adj.size(), -1), low(adj.size()), bel(adj.size(), -1) {
        assert(adj.size() <= std::size_t(std::numeric_limits<int>::max()));
        struct Frame { int vertex; std::size_t next = 0; };
        std::vector<Frame> frames;
        std::vector<int> active;
        frames.reserve(adj.size());
        active.reserve(adj.size());
        int clock = 0;
        auto enter = [&](int vertex) {
            dfn[vertex] = low[vertex] = clock++;
            active.push_back(vertex);
            frames.push_back({vertex});
        };
        for (int root = 0; root < int(adj.size()); ++root) {
            if (dfn[root] != -1) continue;
            enter(root);
            while (!frames.empty()) {
                auto& frame = frames.back();
                int vertex = frame.vertex;
                if (frame.next < adj[vertex].size()) {
                    int next = adj[vertex][frame.next++];
                    assert(0 <= next && next < int(adj.size()));
                    if (dfn[next] == -1) enter(next);
                    else if (bel[next] == -1) low[vertex] = std::min(low[vertex], dfn[next]);
                    continue;
                }
                if (dfn[vertex] == low[vertex]) {
                    int next;
                    do {
                        next = active.back();
                        active.pop_back();
                        bel[next] = cntBlock;
                    } while (next != vertex);
                    ++cntBlock;
                }
                frames.pop_back();
                if (!frames.empty()) {
                    int parent = frames.back().vertex;
                    low[parent] = std::min(low[parent], low[vertex]);
                }
            }
        }
        if (buildCondensation) {
            g.resize(cntBlock);
            for (int vertex = 0; vertex < int(adj.size()); ++vertex)
                for (int next : adj[vertex]) if (bel[vertex] != bel[next])
                    g[bel[vertex]].push_back(bel[next]);
        }
    }
};
using SCC = Scc;
