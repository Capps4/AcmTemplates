# SparseTable GNU++17

RMQ<T,Cmp>(values,cmp) 支持 CTAD、带状态/不可复制的 const-callable 比较器以及不可默认构造但可复制的 T。Cmp 须满足严格弱序。默认返回最小值，greater 返回最大值。不可修改的表只查询 0index 非空 [l,r)。空数组可安全构造但不能查询。

if constexpr 按类型选择构建：可默认构造类型保留 resize+直接赋值的快速循环；其余类型使用 reserve+push_back。最初统一 push_back 的方案使整数建树变慢，已据基准撤回。better 直接调用保存的 cmp，消除 std::min 按值传比较器的复制。operator() 返回表内 const T&，不再复制结果；引用仅在对象不被赋值、移动或销毁时有效。普通 auto 接收仍获得独立副本。输入规模须 <=INT_MAX。

GNU/Clang __builtin_clz 对正数计算 log，避免依赖 std::__lg 内部库符号。构建 O(n log n)，空间 O(n log n)，查询 O(1)（元素和比较操作成本另计）。不拓展为非幂等区间聚合。

Test.cpp 枚举随机数组的所有非空区间，比较 min/max 和自定义比较键，覆盖 move-only 比较器、空表、NonDefault 值及引用返回。Benchmark.cpp 分开比较普通建树、30 万查询和持有 vector 的比较器建树；记录见 Benchmark.csv/Results.json，GCC -O2 与 Clang ASan/UBSan。

自我 Review：类型大驼峰，方法/变量小驼峰；半开区间和 0index；新增接口参数均服务于已有比较器职责，明确了结果引用寿命。未加入修改操作或其他区间算法。

当前计时方法及数据见 [Performance.md](Performance.md)。本文已有数字属于此前计时记录，原报告保存在 `../VerificationHistory/BeforeTimingFence/`；以 Performance.md 为当前性能依据。
