#pragma once
#include <cassert>
#include <functional>
#include <limits>
#include <type_traits>
#include <utility>
#include <vector>

// SNIPPET BEGIN
// Immutable range extremum queries, 0-based [l,r).
template<class T, class Cmp = std::less<T>>
class RMQ {
    Cmp cmp;
    std::vector<std::vector<T>> jump;
    static int floorLog(unsigned value) {
        assert(value > 0);
        return std::numeric_limits<unsigned>::digits - 1 - __builtin_clz(value);
    }
    const T& better(const T& a, const T& b) const { return cmp(b, a) ? b : a; }
public:
    explicit RMQ(const std::vector<T>& a, Cmp cmp = {}) : cmp(std::move(cmp)) {
        if (a.empty()) return;
        int n = int(a.size()), logn = floorLog(unsigned(n));
        jump.resize(logn + 1);
        jump[0] = a;
        for (int level = 1; level <= logn; ++level) {
            int width = 1 << level, half = width / 2;
            int count = n - width + 1;
            if constexpr (std::is_default_constructible_v<T>) {
                jump[level].resize(count);
                for (int i = 0; i < count; ++i)
                    jump[level][i] = better(jump[level - 1][i], jump[level - 1][i + half]);
            } else {
                jump[level].reserve(count);
                for (int i = 0; i < count; ++i)
                    jump[level].push_back(better(jump[level - 1][i], jump[level - 1][i + half]));
            }
        }
    }
    // Borrowed reference valid for the lifetime of this unchanged RMQ.
    const T& operator()(int l, int r) const {
        assert(0 <= l && l < r && !jump.empty() && r <= int(jump[0].size()));
        int log = floorLog(unsigned(r - l));
        return better(jump[log][l], jump[log][r - (1 << log)]);
    }
};
