#pragma once
#include <bits/stdc++.h>
using i64 = long long;
template <class T>
class PersistentTree {
    struct Node {
        int val;
        int l, r;
        explicit Node(int v = 0) : val{v}, l{0}, r{0} {}
    };

    std::vector<Node> t; // memory pool
    std::vector<int> rts;
    const Discreter<T> disc;

    int allocateNode(Node node = Node()) {
        t.push_back(node);
        return (int)t.size() - 1;
    }

    int pushBack(int org, int l, int r, int x) {
        int p = allocateNode(t[org]);
        if (r - l == 1) {
            t[p].val += 1;          // 数点主席树
            // t[p].val += disc.at(x); // 求和主席树 (T val)
            return p;
        }
        int mid = (l + r) / 2;
        if (x < mid) {
            t[p].l = pushBack(t[p].l, l, mid, x);
        } else {
            t[p].r = pushBack(t[p].r, mid, r, x);
        }
        t[p].val = t[t[p].l].val + t[t[p].r].val;
        return p;
    }

    int range(int x, int y, int l, int r, int tl, int tr) const {
        if (tl <= l and r <= tr) {
            return t[y].val - t[x].val;
        }
        int mid = (l + r) / 2;
        int result = 0;
        if (tl < mid) {
            result += range(t[x].l, t[y].l, l, mid, tl, tr);
        }
        if (mid < tr) {
            result += range(t[x].r, t[y].r, mid, r, tl, tr);
        }
        return result;
    }

    int upTo(int x, int y, int l, int r, decltype(Node::val) k) const {
        if (r - l == 1) {
            return l;
        }
        int mid = (l + r) / 2;
        int diff = t[t[y].l].val - t[t[x].l].val;
        if (diff > k) {
            return upTo(t[x].l, t[y].l, l, mid, k);
        } else {
            return upTo(t[x].r, t[y].r, mid, r, k - diff);
        }
    }

public:
    PersistentTree(const std::vector<T> &a)
        : t(1), rts(a.size() + 1), disc(a) {
        t.reserve(a.size() * (std::__lg(disc.size()) + 2));
        rts[0] = allocateNode();
        for (auto i = 1U; i <= a.size(); i++) {
            rts[i] = pushBack(rts[i - 1], 0, disc.size(), disc.rankOf(a[i - 1]));
        }
    }
    // [l, r), [tl, tr)
    int range(int l, int r, T tl, T tr) const {
        assert(0 <= l and l < r and r < (int)rts.size());
        assert(tl < tr);
        int tlRank = disc.rankOf(tl);
        int trRank = disc.rankOf(tr);
        if (trRank - tlRank <= 0) {
            return 0;
        }
        return range(rts[l], rts[r], 0, disc.size(),
            tlRank, trRank
        );
    }
    // [l, r), k = 0 is min (or the next number whose sum <= k)
    T upTo(int l, int r, decltype(Node::val) k) const {
        assert(0 <= l and l < r and r < (int)rts.size());
        int kth = upTo(rts[l], rts[r], 0, disc.size(), k);
        return disc.at(kth);
    }
};

