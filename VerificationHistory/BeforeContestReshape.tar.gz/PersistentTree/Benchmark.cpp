#include <bits/stdc++.h>
#include "../BenchmarkSupport.hpp"
#include "../Discreter/Final.hpp"
namespace Legacy {
// The original snippet refers to an absent Discreter; provide the same final dependency to both implementations.
template<class T>using Discreter=::Discreter<T>;
#include "Original.hpp"
}
#include "Final.hpp"
int main(){
    std::mt19937 rng(113);const int n=100000;std::vector<int> data(n);for(auto& x:data)x=rng()%1000000;
    compare("build",[&]{Legacy::PersistentTree<int> tree(data);return std::uint64_t(tree.upTo(0,n,n/2));},[&]{PersistentTree tree(data);return std::uint64_t(tree.upTo(0,n,n/2));});
    Legacy::PersistentTree<int> old(data);PersistentTree current(data);struct Query{int l,r,tl,tr,k;};std::vector<Query> queries(100000);for(auto& q:queries){q.l=rng()%n;q.r=q.l+1+rng()%(n-q.l);q.tl=rng()%1000000;q.tr=q.tl+1+rng()%(1000001-q.tl);q.k=rng()%(q.r-q.l);}
    compare("range-count",[&]{std::uint64_t sum=0;for(auto q:queries)sum+=old.range(q.l,q.r,q.tl,q.tr);return sum;},[&]{std::uint64_t sum=0;for(auto q:queries)sum+=current.range(q.l,q.r,q.tl,q.tr);return sum;});
    compare("kth-query",[&]{std::uint64_t sum=0;for(auto q:queries)sum+=old.upTo(q.l,q.r,q.k);return sum;},[&]{std::uint64_t sum=0;for(auto q:queries)sum+=current.upTo(q.l,q.r,q.k);return sum;});
}
