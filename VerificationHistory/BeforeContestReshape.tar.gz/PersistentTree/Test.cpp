#include "Final.hpp"
#include "../TestSupport.hpp"
#include <climits>
#include <string>
#include <memory>
int main(){
    PersistentTree<int> empty(std::vector<int>{});CHECK(empty.size()==0 && empty.range(0,0,0,1)==0 && empty.countLessEqual(0,0,INT_MAX)==0);
    for(int test=0;test<300;++test){int n=randomInt(1,100);std::vector<int> a(n);for(auto& x:a)x=randomInt(-100,100);PersistentTree tree(a);for(int query=0;query<500;++query){int l=randomInt(0,n),r=randomInt(l,n),tl=randomInt(-110,110),tr=randomInt(tl,110);int count=0,less=0,lessEqual=0;for(int i=l;i<r;++i){count+=tl<=a[i] && a[i]<tr;less+=a[i]<tl;lessEqual+=a[i]<=tl;}CHECK(tree.range(l,r,tl,tr)==count);CHECK(tree.countLess(l,r,tl)==less);CHECK(tree.countLessEqual(l,r,tl)==lessEqual);if(l<r){std::vector<int> sorted(a.begin()+l,a.begin()+r);std::sort(sorted.begin(),sorted.end());int k=randomInt(0,r-l-1);CHECK(tree.upTo(l,r,k)==sorted[k]);CHECK(tree.upTo(l,r,0)==sorted.front() && tree.upTo(l,r,r-l-1)==sorted.back());}}}
    PersistentTree<long long> limits(std::vector<long long>{LLONG_MAX,LLONG_MIN,0,LLONG_MAX});CHECK(limits.countLessEqual(0,4,LLONG_MAX)==4 && limits.countLess(0,4,LLONG_MIN)==0);CHECK(limits.upTo(0,4,3)==LLONG_MAX);CHECK(limits.range(0,4,LLONG_MIN,LLONG_MAX)==2);
    PersistentTree<bool> bits(std::vector<bool>{true,false,true});CHECK(!bits.upTo(0,3,0) && bits.upTo(0,3,1));CHECK(bits.countLessEqual(0,3,true)==3);
    auto cmp=[p=std::make_unique<int>(1)](int a,int b){return a*(*p)>b*(*p);};PersistentTree<int,decltype(cmp)> reversed(std::vector<int>{1,5,3,5},std::move(cmp));CHECK(reversed.upTo(0,4,0)==5 && reversed.range(0,4,5,1)==3);
    decltype(auto) temporary=PersistentTree<std::string>(std::vector<std::string>{std::string(1000,'x')}).upTo(0,1,0);static_assert(std::is_same_v<decltype(temporary),std::string>);CHECK(temporary.size()==1000);
    std::vector<int> repeated(100000,7);PersistentTree single(repeated);CHECK(single.range(5,99999,7,8)==99994);CHECK(single.upTo(0,100000,99999)==7);
    // Integrated owning pipe basis and tree compression must agree on ranks.
    std::vector<int> input{9,-1,9,4};auto operation=discreteFrom(Discreter(input));auto ranks=input|operation;PersistentTree integration(input);for(std::size_t i=0;i<input.size();++i)CHECK(integration.countLess(0,4,input[i])==int(std::count_if(input.begin(),input.end(),[&](int x){return x<input[i];})));CHECK(ranks==std::vector<int>({2,0,2,1}));
    std::cout<<"PersistentTree: sorted-subarray/count oracles, empty intervals/input, kth edges, extremes, bool, custom comparator, lifetime, integration PASS\n";
}
