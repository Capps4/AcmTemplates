# PersistentTree

依赖 Discreter（再依赖 ListHelper）。保留按前缀版本持久化、区间计数和第 k 小；根 0 使用零节点，构造前按节点上界预留空间。更新沿途直接增加 count，避免重读两个子节点求和。

```cpp
PersistentTree<int> tree(std::vector<int>{5, 2, 5, 7});
int count = tree.range(0, 3, 2, 6); // 3
int kth = tree.upTo(0, 4, 1); // 5，k 从 0 开始
```

range 的位置区间和值区间均为 `[l,r)`，按比较器顺序解释值界限；允许空位置/值区间。countLess/countLessEqual 用 lower/upper rank，处理整数最大值时不需要 value+1。upTo 要求非空位置区间、`0<=k<r-l`；lvalue 返回 const 值引用（bool 返回值），临时树返回拥有值，避免悬空引用。树拥有压缩值及版本，不借用原输入；节点下标/count 为 int，要求预估节点数可表示，断言检查。空间 O(n log m)，构造 O(n log n+n log m)，查询 O(log m)，m 为不同值数量。

保持计数树职责，不增加原版注释提及但未实现的权重和。测试以朴素区间过滤/排序为 oracle，含空输入、全部重复、整数极值、bool、降序不可复制比较器、临时树字符串结果和十万重复值；同时验证整条 ListHelper→Discreter→PersistentTree 依赖。

原版缺失 Discreter，无法直接编译。性能对照给原/新树提供同一个最终版 Discreter，仅测树代码差异；原树快照未改动。当前数据见 [Performance.md](Performance.md)。

风格自审：PersistentTree/Node 大驼峰，现有 range/upTo 名称保留，新增计数接口小驼峰。0index、位置/值半开界限与临时对象结果寿命明确；按下标重取节点，避免 vector 扩容后继续使用引用。

查询使用 unsigned 中点相加，合法非负 int 界限之和可由 unsigned 表示；避免 signed 中点运算中的额外修正指令。去掉了区间计数中的每层相同根分支，本机普通查询接近旧版。
