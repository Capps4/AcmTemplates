#pragma once
#include <cassert>
#include <type_traits>
// SNIPPET BEGIN
template<class T>
struct ExGcdResult { T gcd, x, y; };

// Nonnegative a,b; coefficients and intermediates must fit T.
template<class T>
constexpr ExGcdResult<T> exgcd(T a, T b) {
    static_assert(std::is_integral_v<T> && std::is_signed_v<T>);
    assert(a >= 0 && b >= 0);
    if (b == 0) return {a, 1, 0};
    auto [g, x, y] = exgcd(b, T(a % b));
    return {g, y, T(x - a / b * y)};
}
template<class T>
constexpr T exgcd(T a, T b, T& x, T& y) {
    auto result = exgcd(a, b);
    x = result.x;
    y = result.y;
    return result.gcd;
}
