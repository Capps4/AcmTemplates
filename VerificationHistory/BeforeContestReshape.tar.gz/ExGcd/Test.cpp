#include "Final.hpp"
#include "../TestSupport.hpp"
#include <numeric>
#include <climits>

constexpr auto compileTime = exgcd(35LL, 15LL);
static_assert(compileTime.gcd == 5 && 35 * compileTime.x + 15 * compileTime.y == 5);
int main() {
    auto verify = [](long long a, long long b) {
        auto [g, x, y] = exgcd(a, b);
        CHECK(g == std::gcd(a, b));
        CHECK(__int128(a) * x + __int128(b) * y == g);
        long long oldX, oldY;
        CHECK(exgcd(a, b, oldX, oldY) == g && oldX == x && oldY == y);
    };
    verify(0, 0); verify(0, 17); verify(17, 0);
    verify(LLONG_MAX, LLONG_MAX - 1);
    for (int trial = 0; trial < 100000; ++trial)
        verify(testRng() % 1000000000000ULL, testRng() % 1000000000000ULL);
    std::cout << "100K Bezout/gcd oracles, zero/extreme inputs and constexpr passed\n";
}
