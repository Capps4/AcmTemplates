"""Copy verified final snippets into a reviewable VS Code installation directory."""
import hashlib
import json
from Export import ROOT
from Audit import audit
from Integration import audit as audit_integration

def package():
    manifest = json.loads((ROOT / 'Manifest.json').read_text())
    assert all(item['status'] == 'verified' for item in manifest), 'Finish every module before packaging'
    audit_integration()
    destination = ROOT / 'ReadyToInstall'
    destination.mkdir(exist_ok=True)
    records = []
    for item in manifest:
        audit(item['module'])
        source = ROOT / item['module'] / 'Final.code-snippets'
        content = source.read_bytes()
        filename = item['module'] + '.code-snippets'
        (destination / filename).write_bytes(content)
        records.append({'module': item['module'], 'file': filename,
                        'sha256': hashlib.sha256(content).hexdigest()})
    assert {path.name for path in destination.glob('*.code-snippets')} == {item['file'] for item in records}
    (ROOT / 'Package.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n')
    print(f'{len(records)} verified snippets packaged; original VS Code directory was not written')

if __name__ == '__main__':
    package()
