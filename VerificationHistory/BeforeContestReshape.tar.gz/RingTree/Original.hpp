#pragma once
#include <bits/stdc++.h>
using i64 = long long;
class RingTree {
public:
    std::vector<std::vector<int>> g{};
    std::vector<std::vector<int>> rings{};
    // DSU dsu;

    RingTree(const std::vector<std::vector<int>> &adj)
    //   : dsu(adj.size())
    {
        const int n = adj.size();
        g.resize(n);

        std::vector<int> deg(n, 0);
        std::queue<int> q;
        for (int x = 0; x < n; x++) {
            deg[x] = adj[x].size();
            if (deg[x] == 1) {
                q.push(x);
            }
        }

        while (!q.empty()) {
            int x = q.front();
            q.pop();

            for (int y : adj[x]) {
                if (deg[y] <= 0) continue;
                deg[y] -= 1;
                deg[x] -= 1;
                if (deg[y] == 1) {
                    q.push(y);
                }
                if (deg[y] >= 1) {
                    g[y].push_back(x);
                    // dsu.Union(y, x);
                }
            }
        }

        for (int x = 0; x < n; ++x) {
            assert(deg[x] == 0 or deg[x] == 2);
        }

        for (int s = 0; s < n; s++) {
            if (deg[s] < 2) continue;
            rings.push_back({});
            auto &ring = rings.back();
            int x = s;
            do {
                ring.push_back(x);
                int z = -1;
                for (int y : adj[x]) {
                    if (deg[y] == 2 and y != s) {
                        deg[x] -= 1;
                        deg[y] -= 1;
                        z = y;
                        break;
                    }
                }
                x = z;
            } while (x >= 0);
        }
    }

    RingTree(const std::vector<int> &link)
    //   : dsu(link.size())
    {
        const int n = link.size();
        g.resize(n);

        std::vector<int> deg(n, 0);
        for (int x : link) {
            assert(0 <= x and x < n);
            deg[x] += 1;
        }

        std::queue<int> q;
        for (int x = 0; x < n; x++) {
            if (deg[x] == 0) {
                q.push(x);
            }
        }

        while (!q.empty()) {
            int x = q.front();
            q.pop();
            int y = link[x];
            deg[y] -= 1;
            g[y].push_back(x);
            // dsu.Union(y, x);
            if (deg[y] == 0) {
                q.push(y);
            }
        }

        for (int s = 0; s < n; s++) {
            if (deg[s] < 1) continue;
            rings.push_back({});
            auto &ring = rings.back();
            int x = s;
            do {
                ring.push_back(x);
                deg[x] -= 1;
                x = link[x];
            } while (x != s);
        }
    }
};

