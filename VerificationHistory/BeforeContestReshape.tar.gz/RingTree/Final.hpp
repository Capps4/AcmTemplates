#pragma once
#include <cassert>
#include <cstddef>
#include <limits>
#include <vector>

// SNIPPET BEGIN
class RingTree {
public:
    std::vector<std::vector<int>> g, rings;
    std::vector<int> parent; // -1 for cycle vertices and roots of pure trees.
    explicit RingTree(const std::vector<std::vector<int>>& adj)
        : g(adj.size()), parent(adj.size(), -1) {
        assert(adj.size() <= std::size_t(std::numeric_limits<int>::max()));
        int n = int(adj.size());
        std::vector<std::size_t> degree(n);
        std::vector<unsigned char> removed(n);
        std::vector<int> queue;
        queue.reserve(n);
        for (int vertex = 0; vertex < n; ++vertex) {
            degree[vertex] = adj[vertex].size();
            if (degree[vertex] <= 1) queue.push_back(vertex);
        }
        for (std::size_t head = 0; head < queue.size(); ++head) {
            int vertex = queue[head];
            removed[vertex] = true;
            for (int next : adj[vertex]) {
                assert(0 <= next && next < n);
                if (removed[next]) continue;
                g[next].push_back(vertex);
                parent[vertex] = next;
                if (--degree[next] == 1) queue.push_back(next);
            }
            degree[vertex] = 0;
        }
        for (int vertex = 0; vertex < n; ++vertex) assert(degree[vertex] == 0 || degree[vertex] == 2);
        for (int start = 0; start < n; ++start) {
            if (removed[start]) continue;
            rings.emplace_back();
            int vertex = start;
            while (vertex != -1) {
                rings.back().push_back(vertex);
                removed[vertex] = true;
                int following = -1;
                for (int next : adj[vertex]) {
                    assert(0 <= next && next < n);
                    if (!removed[next]) { following = next; break; }
                }
                vertex = following;
            }
        }
    }
    explicit RingTree(const std::vector<int>& link) : g(link.size()), parent(link.size(), -1) {
        assert(link.size() <= std::size_t(std::numeric_limits<int>::max()));
        int n = int(link.size());
        std::vector<std::size_t> degree(n);
        std::vector<int> queue;
        queue.reserve(n);
        for (int next : link) { assert(0 <= next && next < n); ++degree[next]; }
        for (int vertex = 0; vertex < n; ++vertex) if (!degree[vertex]) queue.push_back(vertex);
        for (std::size_t head = 0; head < queue.size(); ++head) {
            int vertex = queue[head], next = link[vertex];
            g[next].push_back(vertex);
            parent[vertex] = next;
            if (--degree[next] == 0) queue.push_back(next);
        }
        for (int start = 0; start < n; ++start) {
            if (!degree[start]) continue;
            rings.emplace_back();
            int vertex = start;
            do {
                rings.back().push_back(vertex);
                degree[vertex] = 0;
                vertex = link[vertex];
            } while (vertex != start);
        }
    }
};
