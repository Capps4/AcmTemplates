# NTT / GNU++17

保留 Polynomial、Poly、dft/idft、mod、微积分、inv/ln/exp/power/sqrt/prod 与运算符接口。inline static 根表替代类外定义；移除 self 宏，递归 lambda 用 auto&& self。新增可选 PrimitiveRoot 模板参数，默认 3，使用者可给其他固定素数域的原根。

修正旧版实际问题：空 integr 的 inv[1] 越界；power 提前 k%=P 导致常数因子和前导零移位错误；空 dft/idft 现在为 no-op；缺少对应变换根时 inv 通过通用卷积 Newton 迭代回退。mod(k) 仅复制所需前缀，复合加减/标量乘除在原数组中执行，避免旧版全表复制或额外分配。ln 在积分前截到 [0,m-1)，exp/sqrt 最后一轮截到所需精度，避免小特征域中因无关高次项触发非法除法。

依赖固定模数 ModuloInteger（先插入 snippet）。T::getMod() 必须为编译期常量、大于 2 的奇质数，PrimitiveRoot 必须为其原根；断言只检查部分必要条件，不自动证明素性/原根。动态模数不支持。dft/idft 需要非空长度为 2 次幂且整除 P-1；其布局为本模板内部使用的次序，两者互逆。乘法在长度不可支持时退回朴素卷积，超过可用根阶时可能显著变慢。998244353 的最大 2 次幂根阶为 2^23。

系数按 x^0,x^1,... 从 0 索引，mod(k) 截断/补零到 [0,k)。容器和卷积输出最多 2^29 项，形式级数目标 m 最多 2^28 项，实际容量远受内存约束。inv 要求非零常数项；ln 常数项为 1；exp 常数项为 0（空输入视作 0）；sqrt 仅支持常数项为 1 并选择根 +1，不是通用模平方根。integr 输入长度小于 P；ln/exp/power 目标长度不大于 P。负 m 保留原接口的默认长度含义；m=0 返回空，power 的指数必须非负，0^0 返回截断单位多项式。素数、根、下标和系数域契约在关闭断言后也必须满足。

根缓存每个 T/PrimitiveRoot 独立，共享缓存不支持并发调用。Polynomial/Poly 与 FFT 保留共同名字，是替代模板；合用需不同 namespace，最终全局命名兼容性检查尚未结束。

测试：朴素卷积；独立 O(m^2) 逆、指数和平方根递推；重复乘法和朴素二进制幂；求导/积分互逆、exp/ln 互逆、dft/idft 互逆。覆盖空、单项、128 阈值、非 2 次幂精度，97/原根5 与 1000000007/原根5 的回退，小特征域近上界、指数 P/P+1/LLONG_MAX、前导零、自身复合赋值、prod 与 IO。数学模块集成将 comb/Sieve/MillerRabin/PollardRho/NTT/ModuloInteger 一起使用，验证二项式系数与公共动态模数不受污染。GCC -O2 与 Clang ASan/UBSan 均通过。

性能：整条旧/新模板链中，4096/16384 卷积约 2.36x/4.18x，求逆 3.44x、指数 3.03x；这些收益主要来自 ModuloInteger。使用同一新版 Z 的对照，卷积 1.00x、求逆 1.03x，说明 NTT 内核基本持平。原地标量复合乘法约 1.32x。1000000 项截到 64 项的 200 次批次，旧版 35.4ms、新版约 0.009ms；新版计时接近微秒分辨率，仅据此验证 O(k) 前缀复制避免 O(n) 全表复制，不把约 3900x 当作普遍性能。所有数据见 Benchmark.csv。

旧版 self 宏会把 prod 递归 lambda 的 self 参数展开为 (*this)，导致整个头文件无法编译。基准使用 LegacyBaseline.hpp，仅将该未使用方法的 lambda 参数改名为 recurse，未改变被计时的算法；Original.hpp/Original.code-snippets 保持原样。该最小差异已逐字检查，文件 SHA256 在 Results.json。

自评：保留原快速 NTT Newton 路径，补足边界及显式数学前提；避免复杂通用模平方根或任意模卷积。类型大驼峰，方法/变量 lowerCamelCase，循环/截断均 0index 与排他边界。source/snippet、transitive includes 与测试 SHA256 当前有效，原 VS Code 文件未覆盖。

当前计时方法及数据见 [Performance.md](Performance.md)。本文已有数字属于此前计时记录，原报告保存在 `../VerificationHistory/BeforeTimingFence/`；以 Performance.md 为当前性能依据。

集成命名更新：Polynomial→NttPolynomial、Poly→NttPoly。不再导出冲突的旧全局别名；调用方按上述名称迁移，可在自己的局部作用域另设短别名。当前源码与性能数据已按新名字重测，本文较早示例中的旧名字按此替换。
