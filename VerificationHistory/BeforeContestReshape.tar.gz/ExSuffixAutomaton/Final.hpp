#pragma once
#include <algorithm>
#include <array>
#include <cassert>
#include <initializer_list>
#include <limits>
#include <string>
#include <string_view>
#include <vector>

// SNIPPET BEGIN
template<int Z, char Base>
class ExSam {
    static_assert(Z > 0 && int(static_cast<unsigned char>(Base)) + Z <= 256);
    static int code(char c) {
        int value = int(static_cast<unsigned char>(c)) - int(static_cast<unsigned char>(Base));
        assert(0 <= value && value < Z);
        return value;
    }
    [[gnu::always_inline]] int newNode(int length, int source = -1) {
        assert(son.size() < std::size_t(std::numeric_limits<int>::max()));
        if (source < 0) { son.emplace_back(); link.push_back(0); }
        else { son.push_back(son[source]); link.push_back(link[source]); }
        len.push_back(length);
        return ++tot;
    }
public:
    std::vector<std::array<int, Z>> son;
    std::vector<int> len, link;
    int tot = 0, last = 0;
    ExSam() { son.emplace_back(); link.push_back(-1); len.push_back(0); }
    ExSam(std::initializer_list<std::string_view> strings)
        : ExSam(std::vector<std::string_view>(strings)) {}
    template<class Range>
    explicit ExSam(const Range& strings) : ExSam() {
        std::size_t sum = 0;
        for (const auto& text : strings) {
            assert(text.size() <= std::size_t((std::numeric_limits<int>::max() - 1) / 2) - sum);
            sum += text.size();
        }
        son.reserve(2 * sum + 1); link.reserve(2 * sum + 1); len.reserve(2 * sum + 1);
        for (const auto& text : strings) addString(std::string_view(text));
    }
    void addString(std::string_view text) {
        last = 0;
        for (char c : text) exadd(c);
    }
    int exadd(char c, int id = 0) {
        (void)id;
        int value = code(c), state = last;
        if (son[state][value]) {
            int next = son[state][value];
            if (len[next] != len[state] + 1) {
                int clone = newNode(len[state] + 1, next);
                while (state != -1 && son[state][value] == next) {
                    son[state][value] = clone;
                    state = link[state];
                }
                link[next] = clone;
                next = clone;
            }
            return last = next;
        }
        assert(len[last] < std::numeric_limits<int>::max());
        int cur = newNode(len[last] + 1);
        while (state != -1 && !son[state][value]) {
            son[state][value] = cur;
            state = link[state];
        }
        if (state == -1) link[cur] = 0;
        else {
            int next = son[state][value];
            if (len[next] == len[state] + 1) link[cur] = next;
            else {
                int clone = newNode(len[state] + 1, next);
                while (state != -1 && son[state][value] == next) {
                    son[state][value] = clone;
                    state = link[state];
                }
                link[next] = link[cur] = clone;
            }
        }
        return last = cur;
    }
    bool contains(std::string_view text) const {
        int state = 0;
        for (char c : text) {
            state = son[state][code(c)];
            if (!state) return false;
        }
        return true;
    }
    long long distinctSubstringCount() const {
        long long result = 0;
        for (int state = 1; state <= tot; ++state) result += len[state] - len[link[state]];
        return result;
    }
};
