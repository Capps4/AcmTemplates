# DisjointSetUnion / GNU++17

以 DisjointSetUnion<UnionBySize> 表示策略，DSU 别名默认按集合大小合并，用 if constexpr 删除不使用的策略分支；DirectionalDSU 保留旧版第二根挂到第一根的方向语义。保持 find/Union 和公开 size；新增 merge 的 bool 返回值、same、componentSize、componentCount。默认空构造合法，init(n) 可重置。

顶点编号 [0,n)，0index，n>=0。Union 仍返回 void，merge 返回是否合并了不同集合。默认 DSU 的代表元不保证是第一个参数的根，依赖该行为的代码使用 DirectionalDSU。size 只有根位置表示当前集合大小，非根位置保留历史值；componentSize(x) 查询正确大小。componentCount 是当前集合数，不是顶点数。公开 size 的任意修改会破坏大小/策略不变量。

默认按大小合并+路径折半，m 次操作均摊 O(m alpha(n))，初始化/存储 O(n)。定向版本保留路径折半但不保证按秩合并的 alpha(n) 界。类型 PascalCase，保留常用 DSU 缩写与兼容 Union 名称，新增方法 lowerCamelCase。

测试：100 轮随机合并，独立 labels 重命名 oracle 验证连通性、集合大小与组件数；定向版本同时验证每个点的代表元，空状态、重复合并、init 重置、200000 有序合并。GCC -O2、Clang ASan/UBSan 均通过。

自评：原来注释掉的按大小逻辑作为明确策略恢复，同时保留方向行为的可选版本，不把合并方向悄悄变化藏起来。随机合并+查询约 3.08x，有序场景约 2.00x；定向兼容版约 0.97x，基本持平。校验和使用连通集合大小，避免代表元不同导致错误性能比较；结果见 Benchmark.csv。

Final.code-snippets 与 Final.hpp 正文逐字匹配；源码、递归本地 include、测试工具 SHA256 与运行输出在 Results.json。原 VS Code 文件未覆盖。

当前计时方法及数据见 [Performance.md](Performance.md)。本文已有数字属于此前计时记录，原报告保存在 `../VerificationHistory/BeforeTimingFence/`；以 Performance.md 为当前性能依据。
