#pragma once
#include <algorithm>
#include <cassert>
#include <numeric>
#include <vector>

// SNIPPET BEGIN
template<bool UnionBySize = true>
class DisjointSetUnion {
    std::vector<int> parent;
    int components = 0;
public:
    std::vector<int> size;
    explicit DisjointSetUnion(int n = 0) { init(n); }
    void init(int n) {
        assert(n >= 0);
        parent.resize(n);
        std::iota(parent.begin(), parent.end(), 0);
        size.assign(n, 1);
        components = n;
    }
    int find(int x) {
        assert(x >= 0 && std::size_t(x) < parent.size());
        while (x != parent[x]) x = parent[x] = parent[parent[x]];
        return x;
    }
    bool merge(int x, int y) {
        x = find(x); y = find(y);
        if (x == y) return false;
        if constexpr (UnionBySize) if (size[x] < size[y]) std::swap(x, y);
        size[x] += size[y];
        parent[y] = x;
        --components;
        return true;
    }
    void Union(int x, int y) { merge(x, y); }
    bool same(int x, int y) { return find(x) == find(y); }
    int componentSize(int x) { return size[find(x)]; }
    int componentCount() const { return components; }
};
using DSU = DisjointSetUnion<>;
using DirectionalDSU = DisjointSetUnion<false>;
