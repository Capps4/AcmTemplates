#include "Final.hpp"
#include "../TestSupport.hpp"
int main(){
    DSU empty;CHECK(empty.componentCount()==0);
    for(int trial=0;trial<100;++trial){
        int n=randomInt(1,100);DSU d(n);DirectionalDSU directional(n);
        std::vector<int> labels(n),leaders(n);std::iota(labels.begin(),labels.end(),0);std::iota(leaders.begin(),leaders.end(),0);
        int count=n;
        for(int step=0;step<1000;++step){
            int x=randomInt(0,n-1),y=randomInt(0,n-1);int a=labels[x],b=labels[y],root=directional.find(x);
            bool changed=a!=b;
            CHECK(d.merge(x,y)==changed);directional.Union(x,y);
            if(changed){--count;for(int i=0;i<n;++i)if(labels[i]==b)labels[i]=a;for(int i=0;i<n;++i)if(labels[i]==a)leaders[i]=root;}
            CHECK(d.componentCount()==count && directional.componentCount()==count);
            for(int i=0;i<n;++i){CHECK(d.componentSize(i)==int(std::count(labels.begin(),labels.end(),labels[i])));CHECK(directional.find(i)==leaders[i]);CHECK(d.same(x,i)==(labels[x]==labels[i]));}
        }
        d.init(n);CHECK(d.componentCount()==n);for(int i=0;i<n;++i)CHECK(d.find(i)==i && d.componentSize(i)==1);
    }
    DSU chain(200000);for(int i=1;i<200000;++i)chain.Union(i,i-1);CHECK(chain.componentSize(0)==200000 && chain.componentCount()==1);
    DirectionalDSU directional(6);directional.Union(4,1);CHECK(directional.find(1)==4);directional.Union(2,4);CHECK(directional.find(1)==2);
    std::cout<<"DSU: label oracle, component counts/sizes, directional leaders, reset, empty, ordered merges PASS\n";
}
