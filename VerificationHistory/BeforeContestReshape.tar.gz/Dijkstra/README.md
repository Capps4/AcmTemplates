# Dijkstra GNU++17

Dijkstra<Weight, Distance> 缓存各源点最短路。Distance 默认为 common_type_t<Weight, long long>；CTAD 可以写 `Dijkstra solver(graph)`。

`solver(s,t)` 查询单点，`distances(s)` 返回缓存的整行只读引用，`clearCache()` 释放已有行。图通过引用借用，必须比对象活得久，修改图后必须 clearCache。顶点 0index，权重非负。整数路径距离必须严格小于 Inf=numeric_limits<Distance>::max()；超出范围的路径与不可达统一返回 Inf。浮点权重应有限，且精度误差由题目约束处理。

使用结构化绑定和引用遍历边；放松边前检查剩余可表示范围，避免有符号加法溢出，并支持超过旧版 max/2 的合法距离。默认缓存复杂度：每个新源点 O((V+E)log V)，k 个源点缓存 O(kV)。内存不适合无约束地缓存巨大图的所有源点。

Test.cpp 使用 300 个随机图与 Floyd-Warshall 对照，包括重边、自环、零权边、不可达、CTAD、缓存清理和接近 LLONG_MAX 的路径；GCC -O2、Clang ASan/UBSan。Benchmark.cpp 对相同强连通图、相同源点做旧/新对照，避免两版不可达哨兵不同影响校验。七轮中位数和编译器记录见 Results.json。

自我 Review：保持原有缓存职责和查询 API，新增整行读取和显式失效接口均用于缓存管理；类型大驼峰，函数/变量小驼峰，0index；未添加路径还原或其他无关算法。实际性能以 Benchmark.csv 为准，不以语法改写推断加速。

当前计时方法及数据见 [Performance.md](Performance.md)。本文已有数字属于此前计时记录，原报告保存在 `../VerificationHistory/BeforeTimingFence/`；以 Performance.md 为当前性能依据。
