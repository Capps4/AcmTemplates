#pragma once
#include <cassert>
#include <functional>
#include <limits>
#include <queue>
#include <type_traits>
#include <utility>
#include <vector>

// SNIPPET BEGIN
// Nonnegative weights, vertices 0..n-1. Cached graph must remain unchanged.
template<class T, class G = std::common_type_t<T, long long>>
class Dijkstra {
    const std::vector<std::vector<std::pair<int, T>>>& adj;
    std::vector<std::vector<G>> cache;

    std::vector<G> get(int source) const {
        std::vector<G> distance(adj.size(), Inf);
        using Entry = std::pair<G, int>;
        std::priority_queue<Entry, std::vector<Entry>, std::greater<>> queue;
        distance[source] = 0;
        queue.emplace(0, source);
        while (!queue.empty()) {
            auto [nearDist, x] = queue.top();
            queue.pop();
            if (nearDist != distance[x]) continue;
            for (const auto& [y, weight] : adj[x]) {
                assert(0 <= y && y < int(adj.size()) && weight >= 0);
                G w = weight;
                if (w <= Inf - nearDist && distance[y] > nearDist + w) {
                    distance[y] = nearDist + w;
                    queue.emplace(distance[y], y);
                }
            }
        }
        return distance;
    }
public:
    static constexpr G Inf = std::numeric_limits<G>::max();
    explicit Dijkstra(const std::vector<std::vector<std::pair<int, T>>>& graph)
        : adj(graph), cache(graph.size()) {
        static_assert(std::is_arithmetic_v<T> && std::is_arithmetic_v<G>);
        static_assert(std::numeric_limits<G>::digits >= std::numeric_limits<T>::digits,
                      "Distance type must represent the weight type");
    }
    const std::vector<G>& distances(int source) {
        assert(0 <= source && source < int(adj.size()));
        if (cache[source].empty()) cache[source] = get(source);
        return cache[source];
    }
    G operator()(int source, int target) {
        assert(0 <= target && target < int(adj.size()));
        return distances(source)[target];
    }
    void clearCache() {
        cache.clear();
        cache.resize(adj.size());
    }
};
