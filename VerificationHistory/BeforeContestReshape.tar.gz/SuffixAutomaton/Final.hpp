#pragma once
#include <algorithm>
#include <array>
#include <cassert>
#include <limits>
#include <string>
#include <string_view>
#include <vector>

// SNIPPET BEGIN
template<int Z, char Base>
class Sam {
    static_assert(Z > 0 && int(static_cast<unsigned char>(Base)) + Z <= 256);
    static int checkedLength(std::string_view text) {
        assert(text.size() <= std::size_t((std::numeric_limits<int>::max() - 1) / 2));
        return int(text.size());
    }
    static int code(char c) {
        int value = int(static_cast<unsigned char>(c)) - int(static_cast<unsigned char>(Base));
        assert(0 <= value && value < Z);
        return value;
    }
    int newNode(int length, int source = -1) {
        assert(son.size() < std::size_t(std::numeric_limits<int>::max()));
        if (source < 0) { son.emplace_back(); link.push_back(0); }
        else { son.push_back(son[source]); link.push_back(link[source]); }
        len.push_back(length);
        return ++tot;
    }
public:
    std::vector<std::array<int, Z>> son;
    std::vector<int> link, len;
    int last = 0, tot = 0;
    explicit Sam(int expectedLength = 0) {
        assert(expectedLength >= 0 && expectedLength <= (std::numeric_limits<int>::max() - 1) / 2);
        auto capacity = 2 * std::size_t(expectedLength) + 1;
        son.reserve(capacity); link.reserve(capacity); len.reserve(capacity);
        son.emplace_back(); link.push_back(-1); len.push_back(0);
    }
    explicit Sam(std::string_view text) : Sam(checkedLength(text)) {
        for (char c : text) add(c);
    }
    int add(char c) {
        int value = code(c);
        assert(len[last] < std::numeric_limits<int>::max());
        int cur = newNode(len[last] + 1), state = last;
        while (state != -1 && !son[state][value]) {
            son[state][value] = cur;
            state = link[state];
        }
        if (state == -1) link[cur] = 0;
        else {
            int next = son[state][value];
            if (len[state] + 1 == len[next]) link[cur] = next;
            else {
                int clone = newNode(len[state] + 1, next);
                while (state != -1 && son[state][value] == next) {
                    son[state][value] = clone;
                    state = link[state];
                }
                link[next] = link[cur] = clone;
            }
        }
        return last = cur;
    }
    int add(int id, char c) { (void)id; return add(c); }
    bool contains(std::string_view text) const {
        int state = 0;
        for (char c : text) {
            state = son[state][code(c)];
            if (!state) return false;
        }
        return true;
    }
    long long distinctSubstringCount() const {
        long long result = 0;
        for (int state = 1; state <= tot; ++state) result += len[state] - len[link[state]];
        return result;
    }
};
