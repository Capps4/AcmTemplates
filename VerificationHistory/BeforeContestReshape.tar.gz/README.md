# GNU++17 模板升级

51 个非 Geo2/Geo3 模块均有最终版和验证，包含 49 个库模块、2 个入口模板。每个模块在同名目录中保留 Original.code-snippets/Original.hpp，交付 Final.hpp、Final.code-snippets、Test.cpp、Benchmark.cpp、README.md、Results.json、Benchmark.csv 和 Performance.md。类型大驼峰、方法/变量小驼峰，0index、区间 [l,r)；兼容别名和必要接口迁移在模块 README 说明。

[ReadyToInstall](ReadyToInstall/) 包含全部 51 个独立 .code-snippets，文件名/prefix 保留，内容与各模块最终版逐字相同。准备替换时使用这些文件，不要同时安装旧版和最终版而重复注册 prefix。库 snippet 需先插入 Manifest.json 所列依赖；GNU 入口提供 bits/stdc++.h，使用其他编译环境时按 Final.hpp 添加对应标准头。Geo2/Geo3 仍使用已有原文件，Point/Float 的联合测试只读取它们的原样快照。

本任务没有写入原 VS Code snippets 目录。ListHelper 原文件在处理期间有外部排序部分变化，另存 CurrentSource 快照并合入最终版、纳入 SHA 审计。Geo2/Geo3 原源文件也有 SHA 核对。

GCC GNU++17 -O2 和 Clang ASan/UBSan 验证全部模块；性能对照使用相同输入/校验和、预热、编译器屏障、七轮原始数据、中位数和交替测试顺序。性能有输入/机器依赖，不能承诺每项变更提速；Point 宽化、HashMap 重复键、部分图遍历/最大流有明确回退；当前 64 位快读场景也有小幅回退。每个模块的 README/Performance.md 说明接口、边界、复杂度和实测取舍。

另拼接真实导出的 49 个库 snippet，做 GCC/ASan/UBSan 共存运行；两个入口的真实 $0 分别填入测试代码，同时插入全部库片段，核对输入、输出和 case 消费。FFT TestExtra.cpp 实际链接全部 49 个最终版头文件及未修改几何快照，运行同一组跨模块检查；Debuger 还接入本机修改过的 bits/stdc++.h 配置注册钩子。

复测指定模块：`python3 cpp17/Run.py Kmp ZFunction`。生成全部已有 snippet：`python3 cpp17/Export.py`。真实片段集成：`python3 cpp17/Integration.py`。生成可复制文件：`python3 cpp17/Package.py`。核对所有交付、源文件、报告和安装包新鲜度：`python3 cpp17/Audit.py`。源码/依赖/测试工具变化会使相关报告失效，需要复测；Package.py 拒绝打包失效报告。

重要迁移包括 FFT/NTT 的 FftPolynomial/FftPoly/FftReal 与 NttPolynomial/NttPoly，Tree 的半开 PathSegment 与 treeDetail，快读写的 fastIn()/fastOut()，CostFlow 的整数/负环/费用范围契约。详见对应 README 和 [Progress.md](Progress.md)。
