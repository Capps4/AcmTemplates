"""Compile and test only explicitly selected modules, retaining reproducible results."""
import csv
import hashlib
import io
import json
import math
import os
import platform
import re
import subprocess
import statistics
import sys
from pathlib import Path
from Export import export

ROOT = Path(__file__).resolve().parent
CXX = os.environ.get('CXX', '/opt/homebrew/bin/g++-15')
SAN_CXX = os.environ.get('SAN_CXX', '/usr/bin/clang++')

def execute(args, input_text=None):
    result = subprocess.run(args, input=input_text, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(' '.join(map(str, args)) + '\n' + result.stdout + result.stderr)
    return result

def run(args):
    return execute(args).stdout

def check_samples(output, samples):
    rows = list(csv.reader(io.StringIO(output)))
    assert len(rows) == len(samples) and rows, 'Missing benchmark samples'
    for index, (row, sample) in enumerate(zip(rows, samples)):
        assert len(row) == 5 and row[0] == sample['scenario']
        assert int(row[4]) % (1 << 64) == sample['checksum']
        assert sample['first'] == ('final' if index % 2 else 'original')
        medians = []
        for field, column in [('original', 1), ('final', 2)]:
            values = sample[field]
            assert len(values) == 7 and all(math.isfinite(x) and x >= 0 for x in values)
            median = statistics.median(values)
            assert math.isclose(median, float(row[column]), rel_tol=6e-6, abs_tol=1e-9)
            medians.append(median)
        if all(medians):
            assert math.isclose(medians[0] / medians[1], float(row[3]), rel_tol=6e-6)
        else:
            assert row[3] == 'NA'

def performance_text(report):
    lines = ['# 本机性能对照', '',
             '相同输入及校验和；各预热一次、计时七轮取中位数，场景间交替先测旧版/新版。'
             'GCC/Clang 编译器屏障保护计时边界。七轮原始数据和编译命令保存在 Results.json。', '',
             '倍率为旧版耗时 / 新版耗时，大于 1 表示本场景新版较快；不代表其他输入或机器。', '',
             '| 场景 | 旧版 ms | 新版 ms | 倍率 |', '| --- | ---: | ---: | ---: |']
    tiny = []
    for row in csv.reader(io.StringIO(report['benchmark'])):
        lines.append('| ' + ' | '.join(row[:4]) + ' |')
        if min(float(row[1]), float(row[2])) < 0.01:
            tiny.append(row[0])
    if tiny:
        lines.extend(['', '以下短场景接近计时分辨率，倍率仅供观察：' + '、'.join(tiny) + '。'])
    lines.extend(['', '编译器：' + report['compiler'] + '。',
                  '平台：' + report['platform'] + '。', ''])
    return '\n'.join(lines)

def verify(module):
    directory = ROOT / module
    build = directory / 'Build'
    build.mkdir(exist_ok=True)
    export(module)
    tracked = ['Original.hpp', 'Final.hpp', 'Test.cpp', 'Benchmark.cpp', 'Final.code-snippets']
    extra_sources = sorted(directory.glob('TestExtra*.cpp'))
    tracked.extend(path.name for path in extra_sources)
    cases = sorted(directory.glob('TestCase*.cpp'))
    tracked.extend(path.name for path in cases)
    hashes = {name: hashlib.sha256((directory / name).read_bytes()).hexdigest() for name in tracked}
    manifest = {item['module']: item for item in json.loads((ROOT / 'Manifest.json').read_text())}
    dependencies = {}
    def collect(name):
        for dependency in manifest[name]['dependencies']:
            path = f'{dependency}/Final.hpp'
            if path not in dependencies:
                dependencies[path] = hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
                collect(dependency)
    collect(module)
    support = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
               for name in ['TestSupport.hpp', 'BenchmarkSupport.hpp']}
    includes = {}
    def collect_includes(path):
        for relative in re.findall(r'^\s*#include\s+"([^"]+)"', path.read_text(), re.MULTILINE):
            included = (path.parent / relative).resolve()
            name = str(included.relative_to(ROOT))
            if name not in includes:
                includes[name] = hashlib.sha256(included.read_bytes()).hexdigest()
                collect_includes(included)
    for name in ['Test.cpp', 'Benchmark.cpp']:
        collect_includes(directory / name)
    for path in extra_sources:
        collect_includes(path)
    for path in cases:
        collect_includes(path)
    records = []
    for compiler, flags, label in [
        (CXX, ['-O2', '-Wall', '-Wextra'], 'optimized'),
        (SAN_CXX, ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer'], 'sanitized')
    ]:
        command = [compiler, '-std=gnu++17', *flags, str(directory / 'Test.cpp'),
                   *map(str, extra_sources), '-o', str(build / label)]
        run(command)
        output = run([str(build / label)])
        additional = []
        for case in cases:
            executable = build / (label + '-' + case.stem)
            case_command = [compiler, '-std=gnu++17', *flags, str(case), '-o', str(executable)]
            run(case_command)
            additional.append({'command': case_command, 'output': run([str(executable)]).strip()})
        records.append({'command': command, 'output': output.strip(), 'additionalCases': additional})
    command = [CXX, '-std=gnu++17', '-O2', str(directory / 'Benchmark.cpp'), '-o', str(build / 'benchmark')]
    run(command)
    benchmark_result = execute([str(build / 'benchmark')])
    output = benchmark_result.stdout
    samples = [json.loads(line.removeprefix('BENCHMARK_SAMPLES:'))
               for line in benchmark_result.stderr.splitlines() if line.startswith('BENCHMARK_SAMPLES:')]
    check_samples(output, samples)
    for name, digest in hashes.items():
        if hashlib.sha256((directory / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError(f'{module}/{name} changed during verification; rerun this module')
    for name, digest in {**dependencies, **support, **includes}.items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError(f'{name} changed during verification; rerun {module}')
    (directory / 'Benchmark.csv').write_text('scenario,originalMs,finalMs,speedup,checksum\n' + output)
    report = {'formatVersion': 2, 'module': module, 'platform': platform.platform(),
              'compiler': run([CXX, '--version']).splitlines()[0],
              'sanitizerCompiler': run([SAN_CXX, '--version']).splitlines()[0],
              'sha256': hashes,
              'dependencySha256': dependencies, 'supportSha256': support,
              'includeSha256': includes,
              'tests': records, 'benchmarkCommand': command, 'benchmark': output.strip(),
              'benchmarkSamples': samples, 'timingMethod': 'compiler barriers; warmup + median of 7; alternating scenario order'}
    (directory / 'Results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    (directory / 'Performance.md').write_text(performance_text(report))
    print(module + ': correctness + ASan/UBSan PASS\n' + output, flush=True)

if __name__ == '__main__':
    if len(sys.argv) == 1:
        raise SystemExit('Usage: python3 Run.py Module [Module ...]')
    for module in sys.argv[1:]:
        verify(module)
