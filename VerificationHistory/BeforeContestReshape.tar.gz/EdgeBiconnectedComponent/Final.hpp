#pragma once
#include <algorithm>
#include <cassert>
#include <cstddef>
#include <limits>
#include <utility>
#include <vector>

// SNIPPET BEGIN
class EdgeBc {
public:
    std::vector<int> dfn, low, bel, cutDeg;
    std::vector<std::vector<int>> g;
    std::vector<std::pair<int, int>> bridges;
    int cntBlock = 0, componentNum = 0;
    explicit EdgeBc(const std::vector<std::vector<int>>& adj)
        : dfn(adj.size(), -1), low(adj.size()), bel(adj.size(), -1), cutDeg(adj.size()) {
        assert(adj.size() <= std::size_t(std::numeric_limits<int>::max()));
        struct Frame { int vertex, skipParent; std::size_t next = 0; };
        std::vector<Frame> frames;
        std::vector<int> active;
        frames.reserve(adj.size());
        active.reserve(adj.size());
        int clock = 0;
        auto enter = [&](int vertex, int parent) {
            dfn[vertex] = low[vertex] = clock++;
            active.push_back(vertex);
            frames.push_back({vertex, parent});
        };
        for (int root = 0; root < int(adj.size()); ++root) {
            if (dfn[root] != -1) continue;
            ++componentNum;
            enter(root, -1);
            while (!frames.empty()) {
                auto& frame = frames.back();
                int vertex = frame.vertex;
                if (frame.next < adj[vertex].size()) {
                    int next = adj[vertex][frame.next++];
                    assert(0 <= next && next < int(adj.size()));
                    if (next == frame.skipParent) { frame.skipParent = -1; continue; }
                    if (dfn[next] == -1) enter(next, vertex);
                    else low[vertex] = std::min(low[vertex], dfn[next]);
                    continue;
                }
                if (dfn[vertex] == low[vertex]) {
                    int next;
                    do {
                        next = active.back();
                        active.pop_back();
                        bel[next] = cntBlock;
                    } while (next != vertex);
                    ++cntBlock;
                }
                frames.pop_back();
                int parent = frames.empty() ? -1 : frames.back().vertex;
                if (parent != -1) {
                    low[parent] = std::min(low[parent], low[vertex]);
                    if (low[vertex] > dfn[parent]) {
                        bridges.emplace_back(parent, vertex);
                        ++cutDeg[parent];
                        ++cutDeg[vertex];
                    }
                }
            }
        }
        g.resize(cntBlock);
        for (auto [x, y] : bridges) {
            g[bel[x]].push_back(bel[y]);
            g[bel[y]].push_back(bel[x]);
        }
    }
};
using EdgeBC = EdgeBc;
