#pragma once
#include <algorithm>
#include <array>
#include <cassert>
#include <limits>
#include <string>
#include <string_view>
#include <vector>

// SNIPPET BEGIN
template<int Z, char Base>
class Pam {
    static_assert(Z > 0 && int(static_cast<unsigned char>(Base)) + Z <= 256);
    static int checkedLength(std::string_view text) {
        assert(text.size() <= std::size_t(std::numeric_limits<int>::max() - 2));
        return int(text.size());
    }
    static int code(char c) {
        int value = int(static_cast<unsigned char>(c)) - int(static_cast<unsigned char>(Base));
        assert(0 <= value && value < Z);
        return value;
    }
public:
    std::vector<std::array<int, Z>> son;
    std::vector<int> link, len, dep, cnt;
    std::string s;
    int cur = 0, tot = 1;
    explicit Pam(int expectedLength = 0) {
        assert(expectedLength >= 0 && expectedLength <= std::numeric_limits<int>::max() - 2);
        auto capacity = std::size_t(expectedLength) + 2;
        son.reserve(capacity); link.reserve(capacity); len.reserve(capacity);
        dep.reserve(capacity); cnt.reserve(capacity); s.reserve(expectedLength);
        son.resize(2); link = {1, 1}; len = {0, -1}; dep.resize(2); cnt.resize(2);
    }
    explicit Pam(std::string_view text) : Pam(checkedLength(text)) {
        for (char c : text) add(c);
    }
    int getLink(int state, int i) const {
        assert(0 <= state && state <= tot && 0 <= i && i < int(s.size()));
        while (i - len[state] - 1 < 0 || s[i - len[state] - 1] != s[i]) state = link[state];
        return state;
    }
    int add(char c) {
        int value = code(c);
        assert(s.size() < std::size_t(std::numeric_limits<int>::max() - 2));
        int i = int(s.size());
        s.push_back(c);
        int state = getLink(cur, i);
        if (!son[state][value]) {
            int failure = son[getLink(link[state], i)][value];
            son[state][value] = ++tot;
            son.emplace_back(); link.push_back(failure); len.push_back(len[state] + 2);
            dep.push_back(dep[failure] + 1); cnt.push_back(0);
        }
        cur = son[state][value];
        ++cnt[cur];
        return cur;
    }
    int add(int i, char c) { assert(i == int(s.size())); return add(c); }
    std::vector<long long> occurrences() const {
        std::vector<long long> result(cnt.begin(), cnt.end());
        for (int state = tot; state >= 2; --state) result[link[state]] += result[state];
        return result;
    }
    std::vector<std::vector<int>> getLinkTree() const {
        std::vector<std::vector<int>> graph(tot + 1);
        for (int state = 0; state <= tot; ++state)
            if (state != 1) graph[link[state]].push_back(state);
        return graph;
    }
};
