#pragma once
#include <bits/stdc++.h>
using i64 = long long;
template <int Z, char Base>
class Pam {
public:
    std::vector<std::array<int, Z>> son;
    std::vector<int> link, len, dep, cnt;
    std::string s{};

    int cur = 0, tot = 1;

    Pam(int n)
        : son(n + 2), link(n + 2), len(n + 2),
          dep(n + 2), cnt(n + 2) {
        link[0] = 1;
        len[1] = -1;
    }

    Pam(const std::string &s) : Pam(s.size()) {
        for (auto i = 0U; i < s.size(); i++) {
            add(i, s[i]);
        }
    }

    int getLink(int x, int i) {
        while (i - len[x] - 1 < 0 or s[i - len[x] - 1] != s[i]) {
            x = link[x];
        }
        return x;
    }

    void add(int i, char c) {
        c -= Base;
        s.push_back(c);

        int v = getLink(cur, i);

        if (!son[v][c]) {
            link[++tot] = son[getLink(link[v], i)][c];
            son[v][c] = tot;
            len[tot] = len[v] + 2;
            dep[tot] = dep[link[tot]] + 1;
        }

        cur = son[v][c];
        assign(cur, i);
    }

    // Pam 的 linkTree 是 1 为根的
    std::vector<std::vector<int>> getLinkTree() const {
        std::vector<std::vector<int>> adj(tot + 1, std::vector<int>());
        for (int i = 0; i <= tot; i++) {
            if (i != 1) {
                adj[link[i]].push_back(i);
            }
        }
        return adj;
    }

private:
    void assign(int cur, int id) {
        cnt[cur] += 1;
    }
};

